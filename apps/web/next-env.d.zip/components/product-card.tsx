'use client'

import Image from 'next/image'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { ShoppingCart, Star, Video, Image as ImageIcon } from 'lucide-react'
import { formatPrice } from '@/lib/currency'
import { useStore } from '@/lib/store-context'

interface ProductCardProps {
  id: string
  name: string
  price: number | string
  image: string
  description: string
  category?: string
  index?: number
  videoUrl?: string
  images?: string[]
}

export default function ProductCard({
  id,
  name,
  price,
  image,
  description,
  category,
  index = 0,
  videoUrl,
  images = [],
}: ProductCardProps) {
  const { currentStore } = useStore()
  const currency = currentStore?.currency || 'USD'

  return (
    <Link href={`/product/${id}`}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        whileHover={{ scale: 1.05, y: -10 }}
        className="group h-full"
      >
        <div className="bg-card rounded-2xl overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300 h-full flex flex-col border border-border">
          {/* Image Container */}
          <div className="relative w-full aspect-square overflow-hidden bg-secondary">
            <Image
              src={image || 'https://images.unsplash.com/photo-1560393464-5c69a73c5770?w=800&q=80'}
              alt={name}
              fill
              className="object-cover group-hover:scale-110 transition-transform duration-500"
            />
            
            {/* Media Indicators */}
            <div className="absolute top-3 right-3 flex flex-col gap-2">
              {videoUrl && (
                <div className="bg-black/50 backdrop-blur-md p-1.5 rounded-full text-white">
                  <Video className="w-3.5 h-3.5" />
                </div>
              )}
              {images.length > 0 && (
                <div className="bg-black/50 backdrop-blur-md px-2 py-0.5 rounded-full text-white text-[10px] font-bold flex items-center gap-1">
                  <ImageIcon className="w-2.5 h-2.5" />
                  {images.length + 1}
                </div>
              )}
            </div>

            <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
              <div className="flex items-center gap-2 text-white">
                <ShoppingCart className="w-4 h-4" />
                <span className="text-sm font-semibold">View Details</span>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-6 flex-1 flex flex-col">
            {category && (
              <span className="text-xs font-semibold text-accent uppercase tracking-wide mb-2">
                {category}
              </span>
            )}
            <h3 className="text-lg font-bold text-foreground mb-2 line-clamp-2 group-hover:text-primary transition-colors">
              {name}
            </h3>
            <p className="text-sm text-muted-foreground mb-4 line-clamp-2 flex-1">
              {description}
            </p>

            {/* Rating & Price */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-4 h-4 fill-primary text-primary"
                  />
                ))}
                <span className="text-xs text-muted-foreground ml-2">(48)</span>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-border flex items-center justify-between">
              <p className="text-2xl font-bold text-primary">
                {formatPrice(price, currency)}
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </Link>
  )
}
