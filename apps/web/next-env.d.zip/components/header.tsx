'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { ThemeToggle } from './theme-toggle'
import { LanguageSwitcher } from './language-switcher'
import CartDropdown from './cart-dropdown'
import { useAuth } from '@/lib/auth-context'
import { useLanguage } from '@/lib/language-context'
import { LogOut, User, Shield } from 'lucide-react'

export default function Header() {
  const { user, logout } = useAuth()
  const { t } = useLanguage()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <header suppressHydrationWarning className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border h-16" />
    )
  }

  return (
    <header suppressHydrationWarning className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <nav className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="text-xl font-bold text-primary hover:opacity-80 transition-opacity">
          {t('common.home')}
        </Link>
        <div className="flex items-center gap-4">
          <Link href="/" className="text-foreground/70 hover:text-foreground transition-colors text-sm font-medium hidden sm:block">
            {t('common.shop')}
          </Link>
          {user?.role === 'super_admin' && (
            <Link href="/super-admin" className="text-primary font-black transition-colors text-sm flex items-center gap-1.5">
              <Shield className="w-4 h-4" /> <span className="hidden md:inline">{t('nav.admin')}</span>
            </Link>
          )}
          {user?.role === 'store_admin' && (
            <Link href="/admin" className="text-foreground/70 hover:text-foreground transition-colors text-sm font-medium">
              {t('common.dashboard')}
            </Link>
          )}
          <CartDropdown />
          <LanguageSwitcher />
          <ThemeToggle />
          
          {user ? (
            <div className="flex items-center gap-3 pl-3 border-l border-border">
              <span className="text-sm text-foreground/70">{user.name}</span>
              <Link
                href="/dashboard"
                className="p-2 text-foreground/70 hover:text-foreground transition-colors"
                title={t('common.dashboard')}
              >
                <User className="w-5 h-5" />
              </Link>
              <button
                onClick={logout}
                className="p-2 text-foreground/70 hover:text-foreground transition-colors"
                title={t('common.logout')}
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3 pl-3 border-l border-border">
              <Link
                href="/login"
                className="text-sm font-medium text-foreground/70 hover:text-foreground transition-colors"
              >
                {t('common.login')}
              </Link>
              <Link
                href="/register"
                className="px-3 py-1.5 text-sm font-medium bg-primary text-primary-foreground rounded-lg hover:opacity-90 transition-opacity"
              >
                {t('common.register')}
              </Link>
            </div>
          )}
        </div>
      </nav>
    </header>
  )
}
