'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useCart } from '@/lib/cart-context'
import { useStore } from '@/lib/store-context'
import { formatPrice } from '@/lib/currency'
import { motion, AnimatePresence } from 'framer-motion'
import { ShoppingCart, X, Plus, Minus, ShoppingBag } from 'lucide-react'

export default function CartDropdown() {
  const { items, total, removeFromCart, updateQuantity } = useCart()
  const { currentStore } = useStore()
  const [isOpen, setIsOpen] = useState(false)

  const currency = currentStore?.currency || 'USD'

  return (
    <div className="relative">
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2.5 bg-secondary hover:bg-primary/10 rounded-xl text-foreground transition-all border border-border"
        aria-label="Shopping cart"
      >
        <ShoppingCart className="w-5 h-5" />
        {items.length > 0 && (
          <motion.span
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -top-1 -right-1 w-5 h-5 bg-primary text-white rounded-full flex items-center justify-center text-[10px] font-black border-2 border-background"
          >
            {items.length}
          </motion.span>
        )}
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsOpen(false)} className="fixed inset-0 z-40" />
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              className="absolute right-0 top-14 w-[24rem] bg-card border border-border rounded-[2rem] shadow-2xl z-50 overflow-hidden"
            >
              <div className="p-6 border-b border-border flex justify-between items-center bg-secondary/30">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-primary" />
                  <h3 className="font-black text-lg tracking-tight">Your Cart</h3>
                </div>
                <button onClick={() => setIsOpen(false)} className="p-1 hover:bg-background rounded-full transition-colors"><X className="w-5 h-5" /></button>
              </div>

              <div className="max-h-[28rem] overflow-y-auto p-4 space-y-4">
                {items.length === 0 ? (
                  <div className="text-center py-12">
                    <ShoppingCart className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-10" />
                    <p className="text-muted-foreground font-bold">Your cart is empty</p>
                  </div>
                ) : (
                  items.map((item) => (
                    <div key={item.productId} className="flex gap-4 p-3 bg-secondary/50 rounded-2xl border border-border/50 group">
                      <div className="w-20 h-20 rounded-xl overflow-hidden bg-background flex-shrink-0">
                        <img src={item.product.image} alt={item.product.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0 flex flex-col justify-between py-1">
                        <div>
                          <Link href={`/product/${item.productId}`} onClick={() => setIsOpen(false)} className="font-bold text-foreground hover:text-primary transition-colors line-clamp-1">
                            {item.product.name}
                          </Link>
                          <p className="text-sm font-black text-primary">{formatPrice(item.product.discountPrice || item.product.price, currency)}</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-2 bg-background border border-border rounded-lg px-2 py-0.5">
                             <button onClick={() => updateQuantity(item.productId, Math.max(1, item.quantity - 1))} className="text-muted-foreground hover:text-primary transition-colors">−</button>
                             <span className="text-xs font-black min-w-[1rem] text-center">{item.quantity}</span>
                             <button onClick={() => updateQuantity(item.productId, item.quantity + 1)} className="text-muted-foreground hover:text-primary transition-colors">+</button>
                          </div>
                        </div>
                      </div>
                      <button onClick={() => removeFromCart(item.productId)} className="opacity-0 group-hover:opacity-100 p-2 text-destructive hover:bg-destructive/10 rounded-lg transition-all self-start"><X className="w-4 h-4" /></button>
                    </div>
                  ))
                )}
              </div>

              {items.length > 0 && (
                <div className="p-6 bg-secondary/30 border-t border-border space-y-4">
                  <div className="flex justify-between items-center text-xl font-black">
                    <span className="text-muted-foreground text-sm uppercase tracking-widest">Total</span>
                    <span className="text-primary">{formatPrice(total, currency)}</span>
                  </div>
                  <Link
                    href="/checkout"
                    onClick={() => setIsOpen(false)}
                    className="block w-full py-4 bg-primary text-white rounded-2xl font-black text-center shadow-lg hover:brightness-110 transition-all active:scale-95"
                  >
                    Checkout Now
                  </Link>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
