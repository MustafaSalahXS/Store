'use client'

import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { Product } from './products'

export interface CartItem {
  productId: string
  product: Product
  quantity: number
  customizations?: Record<string, any>
  addedAt: string
}

interface CartContextType {
  items: CartItem[]
  total: number
  itemCount: number
  addToCart: (product: Product, quantity: number, customizations?: Record<string, any>) => void
  removeFromCart: (productId: string) => void
  updateQuantity: (productId: string, quantity: number) => void
  clearCart: () => void
  getCartTotal: () => number
}

const CartContext = createContext<CartContextType | undefined>(undefined)

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [total, setTotal] = useState(0)

  // Load cart from localStorage on mount
  useEffect(() => {
    const savedCart = localStorage.getItem('cart')
    if (savedCart) {
      try {
        setItems(JSON.parse(savedCart))
      } catch (error) {
        console.error('Failed to load cart:', error)
        localStorage.removeItem('cart')
      }
    }
  }, [])

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(items))
    calculateTotal()
  }, [items])

  const calculateTotal = () => {
    const cartTotal = items.reduce((sum, item) => {
      const price = Number(item.product.discountPrice || item.product.discount_price || item.product.price)
      return sum + price * item.quantity
    }, 0)
    setTotal(cartTotal)
  }

  const addToCart = (
    product: Product,
    quantity: number,
    customizations?: Record<string, any>
  ) => {
    setItems((prevItems) => {
      const existingItem = prevItems.find((item) => item.productId === product.id)

      if (existingItem && !customizations) {
        // Update quantity if no customizations
        return prevItems.map((item) =>
          item.productId === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        )
      } else {
        // Add as new item
        return [
          ...prevItems,
          {
            productId: product.id,
            product,
            quantity,
            customizations,
            addedAt: new Date().toISOString(),
          },
        ]
      }
    })
  }

  const removeFromCart = (productId: string) => {
    setItems((prevItems) =>
      prevItems.filter((item) => item.productId !== productId)
    )
  }

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId)
      return
    }

    setItems((prevItems) =>
      prevItems.map((item) =>
        item.productId === productId ? { ...item, quantity } : item
      )
    )
  }

  const clearCart = () => {
    setItems([])
  }

  const getCartTotal = () => total

  return (
    <CartContext.Provider
      value={{
        items,
        total,
        itemCount: items.length,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        getCartTotal,
      }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext)
  if (!context) {
    throw new Error('useCart must be used within CartProvider')
  }
  return context
}
