'use client'

import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { useAuth } from './auth-context'
import { api } from './api'

interface Store {
  id: string
  name: string
  slug?: string
  description?: string
  ownerId: string
  isActive: boolean
  currency?: string
}

interface StoreContextType {
  stores: Store[]
  currentStore: Store | null
  setCurrentStore: (store: Store) => void
  isLoading: boolean
  refreshStores: () => Promise<void>
}

const StoreContext = createContext<StoreContextType | undefined>(undefined)

export function StoreProvider({ children }: { children: ReactNode }) {
  const { user, isLoading: isAuthLoading } = useAuth()
  const [stores, setStores] = useState<Store[]>([])
  const [currentStore, setCurrentStore] = useState<Store | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  const loadStores = async () => {
    if (!user) {
      setStores([])
      setCurrentStore(null)
      setIsLoading(false)
      return
    }

    try {
      let storeList: Store[]

      if (user.role === 'super_admin') {
        storeList = await api.admin.getAllStores()
      } else if (user.role === 'store_admin') {
        storeList = await api.stores.list(user.id)
      } else {
        if (user.store_id || user.storeId) {
          const store = await api.stores.get(user.store_id || user.storeId)
          storeList = store ? [store] : []
        } else {
          storeList = []
        }
      }

      setStores(storeList)
      
      // Update currentStore if it matches one in the list (to get new data like currency)
      if (currentStore) {
        const updatedCurrent = storeList.find(s => s.id === currentStore.id)
        if (updatedCurrent) setCurrentStore(updatedCurrent)
      } else if (storeList.length > 0) {
        setCurrentStore(storeList[0])
      }
    } catch (error) {
      console.error('Failed to load stores:', error)
      setStores([])
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    if (!isAuthLoading) {
      loadStores()
    }
  }, [user, isAuthLoading])

  return (
    <StoreContext.Provider
      value={{
        stores,
        currentStore,
        setCurrentStore,
        isLoading,
        refreshStores: loadStores,
      }}
    >
      {children}
    </StoreContext.Provider>
  )
}

export function useStore() {
  const context = useContext(StoreContext)
  if (!context) {
    throw new Error('useStore must be used within StoreProvider')
  }
  return context
}
