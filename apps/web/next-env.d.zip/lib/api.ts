const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000'

async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const url = `${API_URL}${path}`
  
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options?.headers as Record<string, string> || {}),
  }

  // Add auth token if available
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('auth-token')
    if (token) {
      headers['Authorization'] = `Bearer ${token}`
    }
  }

  const res = await fetch(url, { ...options, headers })

  if (!res.ok) {
    const error = await res.json().catch(() => ({ error: res.statusText }))
    throw new Error(error.error || `API error: ${res.status}`)
  }

  return res.json()
}

// ─── AUTH ─────────────────────────────────────────────────
export const api = {
  auth: {
    register: (data: { email: string; password: string; name: string }) =>
      apiFetch<{ success: boolean; userId: string; storeId: string }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    login: (data: { email: string; password: string }) =>
      apiFetch<{
        success: boolean
        user: { id: string; email: string; name: string; role: string; storeId: string }
        session: { accessToken: string; refreshToken: string }
      }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    me: () => apiFetch<any>('/api/auth/me'),
  },

  // ─── PRODUCTS ───────────────────────────────────────────
  products: {
    list: (storeId?: string) =>
      apiFetch<any[]>(`/api/products${storeId ? `?storeId=${storeId}` : ''}`),

    get: (id: string) => apiFetch<any>(`/api/products/${id}`),

    create: (data: any) =>
      apiFetch<any>('/api/products', { method: 'POST', body: JSON.stringify(data) }),

    update: (id: string, data: any) =>
      apiFetch<any>(`/api/products/${id}`, { method: 'PUT', body: JSON.stringify(data) }),

    delete: (id: string) =>
      apiFetch<{ success: boolean }>(`/api/products/${id}`, { method: 'DELETE' }),
  },

  // ─── ORDERS ─────────────────────────────────────────────
  orders: {
    list: (storeId?: string) =>
      apiFetch<any[]>(`/api/orders${storeId ? `?storeId=${storeId}` : ''}`),

    create: (data: any) =>
      apiFetch<any>('/api/orders', { method: 'POST', body: JSON.stringify(data) }),

    updateStatus: (id: string, data: { orderStatus?: string; paymentStatus?: string }) =>
      apiFetch<any>(`/api/orders/${id}/status`, { method: 'PATCH', body: JSON.stringify(data) }),
  },

  // ─── STORES ─────────────────────────────────────────────
  stores: {
    list: (ownerId?: string) =>
      apiFetch<any[]>(`/api/stores${ownerId ? `?ownerId=${ownerId}` : ''}`),

    getBySlug: (slug: string) => apiFetch<any>(`/api/stores/slug/${slug}`),

    get: (id: string) => apiFetch<any>(`/api/stores/${id}`),

    create: (data: any) =>
      apiFetch<any>('/api/stores', { method: 'POST', body: JSON.stringify(data) }),

    update: (id: string, data: any) =>
      apiFetch<any>(`/api/stores/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  },

  // ─── ADMIN ──────────────────────────────────────────────
  admin: {
    getUsers: () => apiFetch<any[]>('/api/admin/users'),

    updateUserRole: (userId: string, role: string) =>
      apiFetch<any>(`/api/admin/users/${userId}/role`, {
        method: 'PATCH',
        body: JSON.stringify({ role }),
      }),

    deleteUser: (userId: string) =>
      apiFetch<{ success: boolean }>(`/api/admin/users/${userId}`, {
        method: 'DELETE',
      }),

    assignStore: (userId: string, storeId: string | null) =>
      apiFetch<any>(`/api/admin/users/${userId}/assign-store`, {
        method: 'PATCH',
        body: JSON.stringify({ storeId }),
      }),

    getAllStores: () => apiFetch<any[]>('/api/admin/stores'),
    
    createStore: (data: any) =>
      apiFetch<any>('/api/admin/stores', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    updateStore: (id: string, data: any) =>
      apiFetch<any>(`/api/admin/stores/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),

    deleteStore: (id: string) =>
      apiFetch<{ success: boolean }>(`/api/admin/stores/${id}`, {
        method: 'DELETE',
      }),

    getStats: () =>
      apiFetch<{ storeCount: number; userCount: number; productCount: number; orderCount: number }>(
        '/api/admin/stats'
      ),
  },

  // ─── UPLOADS ────────────────────────────────────────────
  upload: {
    single: async (file: File) => {
      const formData = new FormData()
      formData.append('file', file)
      
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000'
      const res = await fetch(`${API_URL}/api/upload`, {
        method: 'POST',
        body: formData,
        // Don't set Content-Type, fetch will set it with boundary
      })
      
      if (!res.ok) throw new Error('Upload failed')
      return res.json() as Promise<{ url: string }>
    },

    multiple: async (files: File[]) => {
      const formData = new FormData()
      files.forEach(file => formData.append('files', file))
      
      const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000'
      const res = await fetch(`${API_URL}/api/upload/multiple`, {
        method: 'POST',
        body: formData,
      })
      
      if (!res.ok) throw new Error('Multiple upload failed')
      return res.json() as Promise<{ urls: string[] }>
    },
  },

  // ─── PAYMENTS ───────────────────────────────────────────
  payments: {
    paymob: {
      create: (data: { orderId: string; amount: number; customer: { email: string; name: string; phone: string } }) =>
        apiFetch<{ iframeUrl: string; paymentToken: string }>('/api/payments/paymob/create-payment', {
          method: 'POST',
          body: JSON.stringify(data),
        }),
    },
  },
}
