'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/lib/auth-context'
import { motion, AnimatePresence } from 'framer-motion'
import { Shield, Lock, User as UserIcon, AlertCircle, Loader, ChevronRight, Zap } from 'lucide-react'

export default function SuperLoginPage() {
  const router = useRouter()
  const { login } = useAuth()
  
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const handleSuperLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)

    // Translate username to internal SuperAdmin email
    const internalEmail = username === 'MustafaSalah' ? 'superadmin@system.com' : username

    try {
      const user = await login(internalEmail, password)
      if (user && user.role === 'super_admin') {
        setIsSuccess(true)
        setTimeout(() => {
          router.push('/super-admin')
        }, 1500)
      } else {
        setError('Access Denied: High-level clearance required.')
      }
    } catch (err) {
      setError('Invalid clearance credentials.')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#050505] text-white flex items-center justify-center p-6 overflow-hidden relative">
      {/* Animated Background Gradients */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/20 blur-[120px] rounded-full animate-pulse" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-accent/10 blur-[120px] rounded-full animate-pulse delay-1000" />
      
      {/* Grid Pattern */}
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none" />
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="bg-[#111111]/80 backdrop-blur-3xl border border-white/10 rounded-[2.5rem] p-10 shadow-[0_0_80px_rgba(0,0,0,0.8)] relative overflow-hidden">
          {/* Top Security Accent */}
          <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
          
          <div className="text-center mb-10">
            <motion.div 
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="w-16 h-16 bg-gradient-to-br from-primary to-primary/60 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-primary/20 border border-white/10"
            >
              <Shield className="w-8 h-8 text-white" />
            </motion.div>
            <h1 className="text-2xl font-black tracking-tighter mb-1.5 uppercase text-white">Clearance Level 5</h1>
            <p className="text-[9px] font-black text-muted-foreground uppercase tracking-[0.3em] opacity-60">System Security Protocol</p>
          </div>

          <AnimatePresence mode="wait">
            {!isSuccess ? (
              <motion.form 
                key="login-form"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                onSubmit={handleSuperLogin} 
                className="space-y-6"
              >
                {error && (
                  <motion.div 
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-center gap-3 p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-xs font-bold"
                  >
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    {error}
                  </motion.div>
                )}

                <div className="space-y-2">
                  <label className="text-[9px] font-black text-muted-foreground uppercase tracking-[0.3em] ml-1">Admin Identity</label>
                  <div className="relative group">
                    <div className="absolute left-5 top-1/2 -translate-y-1/2 text-muted-foreground/50 group-focus-within:text-primary transition-colors">
                      <UserIcon className="w-4 h-4" />
                    </div>
                    <input 
                      required
                      value={username}
                      onChange={e => setUsername(e.target.value)}
                      placeholder="Username"
                      className="w-full pl-14 pr-6 py-4 bg-white/[0.03] border border-white/10 rounded-2xl font-bold text-sm focus:border-primary/50 outline-none transition-all placeholder:text-white/10 focus:bg-white/[0.05]"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[9px] font-black text-muted-foreground uppercase tracking-[0.3em] ml-1">Access Key</label>
                  <div className="relative group">
                    <div className="absolute left-5 top-1/2 -translate-y-1/2 text-muted-foreground/50 group-focus-within:text-primary transition-colors">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input 
                      required
                      type="password"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-14 pr-6 py-4 bg-white/[0.03] border border-white/10 rounded-2xl font-bold text-sm focus:border-primary/50 outline-none transition-all placeholder:text-white/10 focus:bg-white/[0.05]"
                    />
                  </div>
                </div>

                <button 
                  disabled={isLoading}
                  className="w-full py-5 bg-primary text-white rounded-[1.5rem] font-black text-sm shadow-xl hover:brightness-110 flex items-center justify-center gap-2 transition-all group active:scale-[0.98] disabled:opacity-50 mt-4"
                >
                  {isLoading ? (
                    <Loader className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      Execute Authorization
                      <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                    </>
                  )}
                </button>
              </motion.form>
            ) : (
              <motion.div 
                key="success-state"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-8"
              >
                <div className="w-14 h-14 bg-green-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-[0_0_30px_rgba(34,197,94,0.3)]">
                  <Zap className="w-7 h-7 text-white animate-pulse" />
                </div>
                <h2 className="text-xl font-black tracking-tight mb-1">Access Granted</h2>
                <p className="text-[10px] text-muted-foreground font-bold tracking-widest uppercase opacity-60 italic">Linking Console...</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        
        <p className="text-center mt-8 text-[8px] font-black text-muted-foreground uppercase tracking-[0.4em] opacity-30">
          Encrypted Connection • Secure Tunnel v4.2
        </p>
      </motion.div>
    </div>
  )
}
