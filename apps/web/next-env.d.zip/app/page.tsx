'use client'

import { useEffect, useState } from 'react'
import Header from '@/components/header'
import ProductCard from '@/components/product-card'
import { motion } from 'framer-motion'
import { useStore } from '@/lib/store-context'
import { api } from '@/lib/api'
import { useLanguage } from '@/lib/language-context'

const DEMO_PRODUCTS = [
  {
    id: 'demo-1',
    name: 'Wedding Invitation Suite',
    price: 49.99,
    category: 'Invitations',
    image: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=800&q=80',
    description: 'Beautiful customizable wedding invitation templates with themes',
    stock: 100,
  },
  {
    id: 'demo-2',
    name: 'Reception Menu Design',
    price: 39.99,
    category: 'Menus',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80',
    description: 'Elegant menu cards for your wedding reception',
    stock: 80,
  },
  {
    id: 'demo-3',
    name: 'Seating Chart Collection',
    price: 44.99,
    category: 'Seating',
    image: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=800&q=80',
    description: 'Premium seating arrangement templates',
    stock: 60,
  },
  {
    id: 'demo-4',
    name: 'Thank You Cards',
    price: 29.99,
    category: 'Cards',
    image: 'https://images.unsplash.com/photo-1505631346881-b72b27e84530?w=800&q=80',
    description: 'Personalized thank you card designs',
    stock: 120,
  },
  {
    id: 'demo-5',
    name: 'Save The Date',
    price: 34.99,
    category: 'Announcements',
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800&q=80',
    description: 'Modern save the date templates',
    stock: 50,
  },
  {
    id: 'demo-6',
    name: 'Complete Bundle',
    price: 129.99,
    category: 'Bundles',
    image: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=800&q=80',
    description: 'All templates + unlimited customization',
    stock: 200,
  },
]

export default function Home() {
  const { currentStore } = useStore()
  const { t } = useLanguage()
  const [products, setProducts] = useState<any[]>(DEMO_PRODUCTS)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadProducts = async () => {
      try {
        // Try to load products from API
        const result = await api.products.list(currentStore?.id)
        if (result && result.length > 0) {
          setProducts(result)
        } else {
          setProducts(DEMO_PRODUCTS)
        }
      } catch (error) {
        console.error('Failed to load products:', error)
        setProducts(DEMO_PRODUCTS)
      } finally {
        setIsLoading(false)
      }
    }

    loadProducts()
  }, [currentStore])

  return (
    <div suppressHydrationWarning className="min-h-screen bg-background">
      <Header />

      {/* Minimal Hero Section */}
      <section className="section-container pt-8 md:pt-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12 md:mb-16"
        >
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold text-foreground mb-4">
            {t('home.heroTitle')}
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {t('home.heroSubtitle')}
          </p>
        </motion.div>
      </section>

      {/* Products Grid */}
      <section className="section-container mb-20">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-secondary rounded-lg h-80 animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product, index) => (
              <ProductCard
                key={product.id}
                {...product}
                index={index}
              />
            ))}
          </div>
        )}
      </section>

      {/* Trust Section */}
      <section className="bg-secondary section-container">
        <div className="py-16 text-center space-y-8">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            Trusted by Thousands
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { label: 'Happy Customers', value: '5,000+' },
              { label: 'Templates Sold', value: '15,000+' },
              { label: 'Average Rating', value: '4.9/5' },
            ].map((stat, idx) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
              >
                <div className="text-4xl md:text-5xl font-bold text-primary mb-2">
                  {stat.value}
                </div>
                <p className="text-muted-foreground">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border section-container">
        <div className="py-12 text-center text-muted-foreground text-sm">
          <p>&copy; 2024 Modern Store. All rights reserved. • 30-day money-back guarantee • Lifetime access</p>
        </div>
      </footer>
    </div>
  )
}
