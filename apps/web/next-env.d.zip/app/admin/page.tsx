'use client'

import { useState, useEffect, useRef } from 'react'
import Header from '@/components/header'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus, Edit, Trash2, Eye, BarChart3, ShoppingCart, Users, Zap, X, Loader, Settings, Video, Image as ImageIcon, Globe, Upload, FileVideo } from 'lucide-react'
import { useAuth } from '@/lib/auth-context'
import { useStore } from '@/lib/store-context'
import { api } from '@/lib/api'
import { formatPrice, CURRENCIES } from '@/lib/currency'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000'

export default function AdminPage() {
  const { user, isLoading: isAuthLoading } = useAuth()
  const { currentStore, refreshStores } = useStore()

  const [activeTab, setActiveTab] = useState<'products' | 'orders' | 'settings'>('products')
  const [products, setProducts] = useState<any[]>([])
  const [orders, setOrders] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isUploading, setIsUploading] = useState(false)

  // Refs for file inputs
  const mainImageRef = useRef<HTMLInputElement>(null)
  const galleryImagesRef = useRef<HTMLInputElement>(null)
  const videoFileRef = useRef<HTMLInputElement>(null)

  // Product Form State
  const [showProductForm, setShowProductForm] = useState(false)
  const [editingProduct, setEditingProduct] = useState<any | null>(null)
  const [productFormData, setProductFormData] = useState({
    name: '',
    description: '',
    price: 0,
    category: '',
    stock: 0,
    sku: '',
    cost: 0,
    isActive: true,
    image: '',
    images: [] as string[],
    videoUrl: ''
  })

  // Store Settings State
  const [storeSettings, setStoreSettings] = useState({
    name: '',
    currency: 'USD',
    description: ''
  })

  useEffect(() => {
    if (currentStore) {
      setStoreSettings({
        name: currentStore.name,
        currency: currentStore.currency || 'USD',
        description: currentStore.description || ''
      })
    }
  }, [currentStore])

  useEffect(() => {
    const loadData = async () => {
      if (!currentStore) {
        setIsLoading(false)
        return
      }

      setIsLoading(true)
      try {
        const [productsData, ordersData] = await Promise.all([
          api.products.list(currentStore.id),
          api.orders.list(currentStore.id),
        ])
        setProducts(productsData)
        setOrders(ordersData)
      } catch (error) {
        console.error('Error loading admin data:', error)
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [currentStore])

  useEffect(() => {
    if (!isAuthLoading && (!user || (user.role !== 'store_admin' && user.role !== 'super_admin'))) {
      window.location.href = '/login'
    }
  }, [user, isAuthLoading])

  if (isAuthLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader className="w-8 h-8 animate-spin text-primary" />
      </div>
    )
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <Loader className="w-12 h-12 animate-spin text-primary mx-auto" />
          <p className="text-muted-foreground font-bold">Synchronizing Store Data...</p>
        </div>
      </div>
    )
  }

  if (!user) return null // Handled by redirect

  if (!currentStore) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <Header />
        <div className="max-w-md w-full text-center space-y-6">
          <div className="w-20 h-20 bg-primary/10 rounded-3xl flex items-center justify-center mx-auto">
            <Zap className="w-10 h-10 text-primary" />
          </div>
          <h2 className="text-3xl font-black tracking-tight">No Store Found</h2>
          <p className="text-muted-foreground font-medium">We couldn't find a store associated with your account. Please contact support or try logging in again.</p>
          <button onClick={() => window.location.href = '/'} className="w-full py-4 bg-primary text-white rounded-2xl font-black shadow-xl">Return to Shop</button>
        </div>
      </div>
    )
  }

  const totalRevenue = orders.reduce((sum: number, o: any) => sum + Number(o.total || 0), 0)
  const stats = [
    { label: 'Total Revenue', value: formatPrice(totalRevenue, currentStore.currency), icon: ShoppingCart, color: 'text-primary' },
    { label: 'Total Orders', value: String(orders.length), icon: Zap, color: 'text-accent' },
    { label: 'Total Products', value: String(products.length), icon: Users, color: 'text-primary' },
    { label: 'Active Products', value: String(products.filter((p: any) => p.isActive).length), icon: BarChart3, color: 'text-accent' },
  ]

  const handleUpdateStore = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    try {
      await api.stores.update(currentStore.id, storeSettings)
      await refreshStores() // This now updates currentStore correctly
      alert('Store settings updated successfully!')
    } catch (error) {
      console.error('Error updating store:', error)
      alert('Failed to update store settings.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'main' | 'gallery' | 'video') => {
    const files = e.target.files
    if (!files || files.length === 0) return

    setIsUploading(true)
    try {
      if (type === 'main') {
        const result = await api.upload.single(files[0])
        setProductFormData(prev => ({ ...prev, image: `${API_URL}${result.url}` }))
      } else if (type === 'gallery') {
        const results = await api.upload.multiple(Array.from(files))
        setProductFormData(prev => ({ 
          ...prev, 
          images: [...prev.images, ...results.urls.map(url => `${API_URL}${url}`)] 
        }))
      } else if (type === 'video') {
        const result = await api.upload.single(files[0])
        setProductFormData(prev => ({ ...prev, videoUrl: `${API_URL}${result.url}` }))
      }
    } catch (error) {
      console.error('Upload failed:', error)
      alert('File upload failed.')
    } finally {
      setIsUploading(false)
    }
  }

  const handleSubmitProduct = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    try {
      const data = { ...productFormData, storeId: currentStore.id }
      if (editingProduct) {
        const updated = await api.products.update(editingProduct.id, data)
        setProducts(products.map(p => p.id === editingProduct.id ? updated : p))
      } else {
        const newProduct = await api.products.create(data)
        setProducts([newProduct, ...products])
      }
      setShowProductForm(false)
      setEditingProduct(null)
    } catch (error) {
      console.error('Error saving product:', error)
      alert('Failed to save product.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleEditProduct = (product: any) => {
    setEditingProduct(product)
    setProductFormData({
      name: product.name,
      description: product.description || '',
      price: Number(product.price),
      category: product.category || '',
      stock: product.stock || 0,
      sku: product.sku || '',
      cost: Number(product.cost || 0),
      isActive: product.isActive !== false,
      image: product.image || '',
      images: product.images || [],
      videoUrl: product.videoUrl || ''
    })
    setShowProductForm(true)
  }

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Delete this product?')) return
    try {
      await api.products.delete(id)
      setProducts(products.filter(p => p.id !== id))
    } catch (error) {
      alert('Failed to delete product.')
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <div className="section-container py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-4xl font-black tracking-tight">Store Admin</h1>
            <p className="text-muted-foreground mt-1 font-medium">
              Store: <span className="text-primary">{currentStore.name}</span> • Currency: <span className="text-primary font-bold">{currentStore.currency || 'USD'}</span>
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 mb-10 border-b border-border/50">
          {([
            { id: 'products', label: 'Inventory', icon: ShoppingCart },
            { id: 'orders', label: 'Sales', icon: Zap },
            { id: 'settings', label: 'Settings', icon: Settings }
          ] as const).map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-6 py-4 font-black transition-all border-b-4 ${
                activeTab === tab.id ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              <tab.icon className="w-5 h-5" />
              {tab.label}
            </button>
          ))}
        </div>

        {activeTab === 'products' && (
          <div className="space-y-8">
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {stats.map((stat, idx) => (
                <motion.div key={idx} whileHover={{ y: -5 }} className="bg-card rounded-3xl p-8 border border-border shadow-xl">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-black text-muted-foreground uppercase tracking-widest">{stat.label}</span>
                    <div className={`p-2 rounded-xl bg-secondary ${stat.color}`}><stat.icon className="w-5 h-5" /></div>
                  </div>
                  <p className="text-3xl font-black">{stat.value}</p>
                </motion.div>
              ))}
            </div>

            {/* Products Table */}
            <div className="bg-card rounded-[2.5rem] border border-border p-8 shadow-2xl">
              <div className="flex justify-between items-center mb-10">
                <h2 className="text-3xl font-black tracking-tight">Product Catalog</h2>
                <button
                  onClick={() => {
                    setEditingProduct(null)
                    setProductFormData({ name: '', description: '', price: 0, category: '', stock: 0, sku: '', cost: 0, isActive: true, image: '', images: [], videoUrl: '' })
                    setShowProductForm(true)
                  }}
                  className="flex items-center gap-2 px-8 py-4 bg-primary text-white rounded-2xl font-black shadow-lg hover:brightness-110 transition-all active:scale-95"
                >
                  <Plus className="w-5 h-5" /> Create New
                </button>
              </div>

              {/* Product Form Modal */}
              <AnimatePresence>
                {showProductForm && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
                    <motion.div initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} className="bg-card w-full max-w-5xl max-h-[90vh] overflow-y-auto rounded-[3rem] p-10 border border-border shadow-2xl relative">
                      <button onClick={() => setShowProductForm(false)} className="absolute top-8 right-8 p-2 hover:bg-secondary rounded-full"><X className="w-6 h-6"/></button>
                      
                      <h3 className="text-4xl font-black mb-10 tracking-tight">{editingProduct ? 'Update Product' : 'New Product'}</h3>

                      <form onSubmit={handleSubmitProduct} className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                        {/* Left Column: Basic Info */}
                        <div className="space-y-6">
                          <div className="space-y-2">
                            <label className="text-sm font-black text-muted-foreground uppercase tracking-widest ml-1">Product Title</label>
                            <input required value={productFormData.name} onChange={e => setProductFormData({...productFormData, name: e.target.value})} className="w-full p-4 bg-secondary/50 border border-border rounded-2xl font-bold focus:border-primary outline-none" placeholder="e.g. Premium Invitation" />
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <label className="text-sm font-black text-muted-foreground uppercase tracking-widest ml-1">Price ({currentStore.currency})</label>
                              <input type="number" step="0.01" required value={productFormData.price} onChange={e => setProductFormData({...productFormData, price: Number(e.target.value)})} className="w-full p-4 bg-secondary/50 border border-border rounded-2xl font-bold" />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm font-black text-muted-foreground uppercase tracking-widest ml-1">Stock Level</label>
                              <input type="number" value={productFormData.stock} onChange={e => setProductFormData({...productFormData, stock: Number(e.target.value)})} className="w-full p-4 bg-secondary/50 border border-border rounded-2xl font-bold" />
                            </div>
                          </div>

                          <div className="space-y-2">
                            <label className="text-sm font-black text-muted-foreground uppercase tracking-widest ml-1">Description</label>
                            <textarea value={productFormData.description} onChange={e => setProductFormData({...productFormData, description: e.target.value})} className="w-full p-4 bg-secondary/50 border border-border rounded-2xl font-medium min-h-[150px]" placeholder="Tell us about the product..." />
                          </div>
                        </div>

                        {/* Right Column: Media Uploads */}
                        <div className="space-y-6">
                          <div className="bg-secondary/30 p-6 rounded-[2rem] border border-border space-y-6">
                            <h4 className="font-black text-xl flex items-center gap-2"><ImageIcon className="w-5 h-5 text-primary" /> Visual Media</h4>
                            
                            {/* Main Image */}
                            <div className="space-y-3">
                              <label className="text-xs font-black text-muted-foreground uppercase tracking-widest">Main Product Image</label>
                              <div className="flex items-center gap-4">
                                <div className="w-20 h-20 bg-background rounded-2xl border-2 border-dashed border-border overflow-hidden flex items-center justify-center">
                                  {productFormData.image ? <img src={productFormData.image} className="w-full h-full object-cover" /> : <Upload className="w-6 h-6 text-muted-foreground opacity-20" />}
                                </div>
                                <button type="button" onClick={() => mainImageRef.current?.click()} className="px-4 py-2 bg-background border border-border rounded-xl font-bold text-sm hover:bg-secondary">Choose File</button>
                                <input type="file" ref={mainImageRef} hidden accept="image/*" onChange={e => handleFileUpload(e, 'main')} />
                              </div>
                            </div>

                            {/* Gallery */}
                            <div className="space-y-3">
                              <label className="text-xs font-black text-muted-foreground uppercase tracking-widest">Gallery Images ({productFormData.images.length})</label>
                              <div className="flex flex-wrap gap-2 mb-3">
                                {productFormData.images.map((img, i) => (
                                  <div key={i} className="relative group w-16 h-16">
                                    <img src={img} className="w-full h-full object-cover rounded-lg border border-border" />
                                    <button type="button" onClick={() => setProductFormData(p => ({ ...p, images: p.images.filter((_, idx) => idx !== i) }))} className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"><X className="w-3 h-3"/></button>
                                  </div>
                                ))}
                                <button type="button" onClick={() => galleryImagesRef.current?.click()} className="w-16 h-16 border-2 border-dashed border-border rounded-xl flex items-center justify-center text-muted-foreground hover:border-primary hover:text-primary transition-all"><Plus className="w-6 h-6"/></button>
                                <input type="file" ref={galleryImagesRef} hidden multiple accept="image/*" onChange={e => handleFileUpload(e, 'gallery')} />
                              </div>
                            </div>

                            {/* Video */}
                            <div className="space-y-3">
                              <label className="text-xs font-black text-muted-foreground uppercase tracking-widest">Product Video</label>
                              <div className="flex items-center gap-4">
                                <div className="flex-1 bg-background p-3 rounded-xl border border-border flex items-center gap-3">
                                  <FileVideo className="w-5 h-5 text-primary" />
                                  <span className="text-xs font-bold text-muted-foreground truncate">{productFormData.videoUrl ? 'Video Attached' : 'No video selected'}</span>
                                </div>
                                <button type="button" onClick={() => videoFileRef.current?.click()} className="px-4 py-2 bg-background border border-border rounded-xl font-bold text-sm hover:bg-secondary">Upload</button>
                                <input type="file" ref={videoFileRef} hidden accept="video/*" onChange={e => handleFileUpload(e, 'video')} />
                              </div>
                            </div>
                          </div>

                          <div className="pt-4 flex gap-4">
                            <button type="button" onClick={() => setShowProductForm(false)} className="flex-1 py-4 bg-secondary font-black rounded-2xl">Cancel</button>
                            <button type="submit" disabled={isSubmitting || isUploading} className="flex-[2] py-4 bg-primary text-white font-black rounded-2xl shadow-xl hover:brightness-110 flex items-center justify-center gap-3">
                              {(isSubmitting || isUploading) && <Loader className="w-5 h-5 animate-spin" />}
                              {editingProduct ? 'Save Changes' : 'Create Product'}
                            </button>
                          </div>
                        </div>
                      </form>
                    </motion.div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="border-b border-border text-muted-foreground text-xs uppercase tracking-[0.2em]">
                    <tr>
                      <th className="py-6 px-4 font-black">Product</th>
                      <th className="py-6 px-4 font-black">Price</th>
                      <th className="py-6 px-4 font-black">Inventory</th>
                      <th className="py-6 px-4 font-black">Media</th>
                      <th className="py-6 px-4 text-right font-black">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map(product => (
                      <tr key={product.id} className="border-b border-border/50 group hover:bg-secondary/30 transition-colors">
                        <td className="py-6 px-4">
                          <div className="flex items-center gap-4">
                            <div className="w-14 h-14 bg-secondary rounded-xl overflow-hidden border border-border">
                              {product.image && <img src={product.image} className="w-full h-full object-cover" />}
                            </div>
                            <div>
                              <div className="font-black text-lg">{product.name}</div>
                              <div className="text-xs font-bold text-muted-foreground">{product.category || 'No Category'}</div>
                            </div>
                          </div>
                        </td>
                        <td className="py-6 px-4"><span className="text-lg font-black text-primary">{formatPrice(product.price, currentStore.currency)}</span></td>
                        <td className="py-6 px-4">
                          <div className="flex items-center gap-2">
                             <div className={`w-2 h-2 rounded-full ${product.stock > 10 ? 'bg-green-500' : product.stock > 0 ? 'bg-yellow-500' : 'bg-red-500'}`} />
                             <span className="font-black text-sm">{product.stock} units</span>
                          </div>
                        </td>
                        <td className="py-6 px-4">
                           <div className="flex gap-2">
                              {product.image && <ImageIcon className="w-4 h-4 text-primary" />}
                              {product.videoUrl && <Video className="w-4 h-4 text-accent" />}
                              {product.images?.length > 0 && <span className="text-[10px] font-black bg-secondary px-1.5 py-0.5 rounded-md">+{product.images.length}</span>}
                           </div>
                        </td>
                        <td className="py-6 px-4 text-right">
                           <div className="flex justify-end gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
                              <button onClick={() => handleEditProduct(product)} className="p-2 hover:bg-primary/10 rounded-xl transition-colors"><Edit className="w-5 h-5 text-primary" /></button>
                              <button onClick={() => handleDeleteProduct(product.id)} className="p-2 hover:bg-red-500/10 rounded-xl transition-colors"><Trash2 className="w-5 h-5 text-red-500" /></button>
                           </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="max-w-3xl mx-auto space-y-8">
            <div className="bg-card rounded-[3rem] border border-border p-12 shadow-2xl">
              <h2 className="text-4xl font-black mb-10 tracking-tight flex items-center gap-4"><Settings className="w-10 h-10 text-primary" /> General Settings</h2>
              
              <form onSubmit={handleUpdateStore} className="space-y-8">
                <div className="space-y-2">
                  <label className="text-sm font-black text-muted-foreground uppercase tracking-widest ml-1">Store Name</label>
                  <input required value={storeSettings.name} onChange={e => setStoreSettings({...storeSettings, name: e.target.value})} className="w-full p-5 bg-secondary/50 border border-border rounded-[1.5rem] font-black text-xl" />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-black text-muted-foreground uppercase tracking-widest ml-1">Display Currency</label>
                  <div className="relative">
                    <select
                      value={storeSettings.currency}
                      onChange={e => setStoreSettings({...storeSettings, currency: e.target.value})}
                      className="w-full p-5 bg-secondary/50 border border-border rounded-[1.5rem] font-black text-xl appearance-none outline-none focus:border-primary"
                    >
                      {CURRENCIES.map(c => (
                        <option key={c.code} value={c.code}>{c.name} ({c.code} - {c.symbol})</option>
                      ))}
                    </select>
                    <Globe className="absolute right-6 top-6 w-6 h-6 text-muted-foreground pointer-events-none" />
                  </div>
                  <p className="text-xs font-bold text-muted-foreground mt-3 flex items-center gap-2"><Zap className="w-3 h-3 text-accent" /> This will instantly update the formatting for all products across your store.</p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-black text-muted-foreground uppercase tracking-widest ml-1">Store Description</label>
                  <textarea value={storeSettings.description} onChange={e => setStoreSettings({...storeSettings, description: e.target.value})} className="w-full p-5 bg-secondary/50 border border-border rounded-[1.5rem] font-medium min-h-[120px]" />
                </div>

                <button type="submit" disabled={isSubmitting} className="w-full py-6 bg-primary text-white rounded-[2rem] font-black text-2xl shadow-2xl hover:brightness-110 transition-all flex items-center justify-center gap-4">
                  {isSubmitting && <Loader className="w-6 h-6 animate-spin" />} Save Settings
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
