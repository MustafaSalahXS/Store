'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import Header from '@/components/header'
import { useAuth } from '@/lib/auth-context'
import { getUserOrders, Order } from '@/lib/payments'
import { motion } from 'framer-motion'
import { ShoppingBag, Package, Truck, CheckCircle, Clock, AlertCircle, ChevronRight } from 'lucide-react'

const STATUS_CONFIG = {
  pending: { color: 'text-yellow-600', bg: 'bg-yellow-50', icon: Clock, label: 'Pending' },
  processing: { color: 'text-blue-600', bg: 'bg-blue-50', icon: Package, label: 'Processing' },
  shipped: { color: 'text-blue-600', bg: 'bg-blue-50', icon: Truck, label: 'Shipped' },
  delivered: { color: 'text-green-600', bg: 'bg-green-50', icon: CheckCircle, label: 'Delivered' },
  cancelled: { color: 'text-red-600', bg: 'bg-red-50', icon: AlertCircle, label: 'Cancelled' },
}

export default function OrdersPage() {
  const { user, loading: authLoading } = useAuth()
  const [orders, setOrders] = useState<Order[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)

  useEffect(() => {
    const loadOrders = async () => {
      if (!user) {
        setIsLoading(false)
        return
      }

      try {
        const result = await getUserOrders(user.id)
        setOrders(result)
      } catch (error) {
        console.error('Failed to load orders:', error)
      } finally {
        setIsLoading(false)
      }
    }

    loadOrders()
  }, [user])

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="section-container py-12 text-center">
          <div className="w-12 h-12 border-4 border-secondary border-t-primary rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Loading orders...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="section-container py-12 text-center">
          <ShoppingBag className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
          <h1 className="text-2xl font-bold text-foreground mb-2">Sign In Required</h1>
          <p className="text-muted-foreground mb-6">Please sign in to view your orders</p>
          <Link
            href="/login"
            className="inline-block px-6 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 transition-opacity"
          >
            Sign In
          </Link>
        </div>
      </div>
    )
  }

  if (orders.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="section-container py-12">
          <h1 className="text-3xl font-bold text-foreground mb-8">My Orders</h1>
          <div className="text-center py-12">
            <ShoppingBag className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
            <h2 className="text-xl font-semibold text-foreground mb-2">No Orders Yet</h2>
            <p className="text-muted-foreground mb-6">You haven&apos;t placed any orders yet</p>
            <Link
              href="/"
              className="inline-block px-6 py-3 bg-primary text-primary-foreground rounded-lg font-semibold hover:opacity-90 transition-opacity"
            >
              Start Shopping
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="section-container py-12">
        <h1 className="text-3xl font-bold text-foreground mb-8">My Orders</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Orders List */}
          <div className="lg:col-span-2 space-y-4">
            {orders.map((order, idx) => {
              const statusConfig = STATUS_CONFIG[order.order_status]
              const StatusIcon = statusConfig.icon

              return (
                <motion.button
                  key={order.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  onClick={() => setSelectedOrder(order)}
                  className={`w-full text-left p-6 rounded-lg border-2 transition-all ${
                    selectedOrder?.id === order.id
                      ? 'border-primary bg-primary/5'
                      : 'border-border bg-card hover:border-primary'
                  }`}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-bold text-lg text-foreground">Order #{order.id.slice(0, 8)}</h3>
                      <p className="text-sm text-muted-foreground">
                        {new Date(order.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <StatusIcon className={`w-5 h-5 ${statusConfig.color}`} />
                      <span className={`text-sm font-semibold ${statusConfig.color}`}>
                        {statusConfig.label}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    <p className="text-sm text-muted-foreground">
                      {order.items.length} item{order.items.length !== 1 ? 's' : ''} • EGP {order.total.toFixed(2)}
                    </p>
                    <p className="text-sm text-foreground font-medium">
                      {order.customer_name}
                    </p>
                  </div>

                  <div className="flex items-center justify-between">
                    <p className={`px-3 py-1 rounded-full text-xs font-semibold ${statusConfig.bg} ${statusConfig.color}`}>
                      {order.payment_method === 'card' && 'Card Payment'}
                      {order.payment_method === 'vodafone_cash' && 'Vodafone Cash'}
                      {order.payment_method === 'instapay' && 'InstaPay'}
                      {order.payment_method === 'whatsapp' && 'WhatsApp Payment'}
                    </p>
                    <ChevronRight className="w-5 h-5 text-muted-foreground" />
                  </div>
                </motion.button>
              )
            })}
          </div>

          {/* Order Details Sidebar */}
          {selectedOrder && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-card rounded-lg border border-border p-6 h-fit sticky top-24"
            >
              <h3 className="text-xl font-bold text-foreground mb-6">Order Details</h3>

              {/* Order ID & Status */}
              <div className="mb-6 pb-6 border-b border-border">
                <p className="text-sm text-muted-foreground mb-1">Order ID</p>
                <p className="font-mono text-sm bg-secondary px-3 py-2 rounded mb-4">
                  {selectedOrder.id}
                </p>
                <div className="flex items-center gap-2">
                  {(() => {
                    const config = STATUS_CONFIG[selectedOrder.order_status]
                    const Icon = config.icon
                    return (
                      <>
                        <Icon className={`w-5 h-5 ${config.color}`} />
                        <span className={`font-semibold ${config.color}`}>
                          {config.label}
                        </span>
                      </>
                    )
                  })()}
                </div>
              </div>

              {/* Customer Info */}
              <div className="mb-6 pb-6 border-b border-border space-y-3">
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide">Name</p>
                  <p className="text-foreground">{selectedOrder.customer_name}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide">Email</p>
                  <p className="text-foreground break-all">{selectedOrder.customer_email}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide">Phone</p>
                  <p className="text-foreground">{selectedOrder.customer_phone}</p>
                </div>
              </div>

              {/* Items */}
              <div className="mb-6 pb-6 border-b border-border">
                <p className="text-xs text-muted-foreground uppercase tracking-wide mb-3">Items</p>
                <div className="space-y-2">
                  {selectedOrder.items.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <div>
                        <p className="font-medium text-foreground">{item.product_name}</p>
                        <p className="text-xs text-muted-foreground">Qty: {item.quantity}</p>
                      </div>
                      <p className="text-foreground font-medium">
                        EGP {(item.price * item.quantity).toFixed(2)}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Pricing */}
              <div className="space-y-2 text-sm">
                <div className="flex justify-between text-muted-foreground">
                  <span>Subtotal</span>
                  <span>EGP {selectedOrder.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Tax</span>
                  <span>EGP {selectedOrder.tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>Shipping</span>
                  <span>EGP {selectedOrder.shipping.toFixed(2)}</span>
                </div>
                <div className="border-t border-border pt-2 flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span className="text-primary">EGP {selectedOrder.total.toFixed(2)}</span>
                </div>
              </div>

              {/* Payment Method */}
              <div className="mt-6 p-3 bg-secondary rounded-lg">
                <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
                  Payment Method
                </p>
                <p className="font-semibold text-foreground">
                  {selectedOrder.payment_method === 'card' && 'Credit/Debit Card'}
                  {selectedOrder.payment_method === 'vodafone_cash' && 'Vodafone Cash'}
                  {selectedOrder.payment_method === 'instapay' && 'InstaPay'}
                  {selectedOrder.payment_method === 'whatsapp' && 'WhatsApp Payment'}
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  Status: {selectedOrder.payment_status === 'confirmed' ? 'Paid' : 'Pending'}
                </p>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  )
}
