'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import Header from '@/components/header'
import { api } from '@/lib/api'
import { useCart } from '@/lib/cart-context'
import { useStore } from '@/lib/store-context'
import { formatPrice } from '@/lib/currency'
import { Star, Shield, Download, Clock, Check, ShoppingCart, AlertCircle, ChevronLeft, PlayCircle, Image as ImageIcon } from 'lucide-react'

export default function ProductPage() {
  const params = useParams()
  const router = useRouter()
  const { addToCart } = useCart()
  const { currentStore } = useStore()
  const productId = params.id as string

  const [product, setProduct] = useState<any | null>(null)
  const [quantity, setQuantity] = useState(1)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState('')
  const [addedToCart, setAddedToCart] = useState(false)
  
  const [activeMedia, setActiveMedia] = useState<string | null>(null)
  const [isVideoActive, setIsVideoActive] = useState(false)

  useEffect(() => {
    const loadProduct = async () => {
      try {
        const result = await api.products.get(productId)
        if (!result) {
          setError('Product not found')
        } else {
          setProduct(result)
          setActiveMedia(result.image || result.images?.[0])
        }
      } catch (err) {
        setError('Failed to load product')
        console.error(err)
      } finally {
        setIsLoading(false)
      }
    }

    loadProduct()
  }, [productId])

  const handleAddToCart = () => {
    if (!product || quantity <= 0) return
    addToCart(product, quantity)
    setAddedToCart(true)
    setTimeout(() => setAddedToCart(false), 2000)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="section-container py-12 text-center">
          <div className="w-12 h-12 border-4 border-secondary border-t-primary rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Loading product...</p>
        </div>
      </div>
    )
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="section-container py-12">
          <div className="flex items-center gap-3 p-4 bg-destructive/10 border border-destructive/30 rounded-lg mb-6">
            <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0" />
            <p className="text-destructive">{error || 'Product not found'}</p>
          </div>
          <button onClick={() => router.back()} className="flex items-center gap-2 text-primary hover:underline font-semibold">
            <ChevronLeft className="w-5 h-5" /> Go Back
          </button>
        </div>
      </div>
    )
  }

  const discountPrice = product.discount_price || product.discountPrice
  const allImages = [product.image, ...(product.images || [])].filter(Boolean)
  const currency = currentStore?.currency || 'USD'

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="section-container py-12">
        <button onClick={() => router.back()} className="flex items-center gap-2 text-primary hover:underline font-semibold mb-8">
          <ChevronLeft className="w-5 h-5" /> Back
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
          {/* Media Section */}
          <div className="space-y-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="relative aspect-square bg-secondary rounded-2xl overflow-hidden border border-border shadow-inner">
              {isVideoActive ? (
                <div className="w-full h-full flex items-center justify-center bg-black">
                   {product.videoUrl?.includes('youtube.com') || product.videoUrl?.includes('youtu.be') ? (
                     <iframe className="w-full h-full" src={product.videoUrl.replace('watch?v=', 'embed/')} title="Product Video" allowFullScreen />
                   ) : (
                     <video src={product.videoUrl} controls className="w-full h-full" />
                   )}
                   <button onClick={() => setIsVideoActive(false)} className="absolute top-4 right-4 bg-white/20 hover:bg-white/40 p-2 rounded-full backdrop-blur-md text-white"><X className="w-5 h-5"/></button>
                </div>
              ) : (
                <img src={activeMedia || ''} alt={product.name} className="w-full h-full object-cover" />
              )}
            </motion.div>

            {/* Thumbnails */}
            <div className="flex flex-wrap gap-3">
              {allImages.map((img, i) => (
                <button
                  key={i}
                  onClick={() => { setActiveMedia(img); setIsVideoActive(false); }}
                  className={`w-20 h-20 rounded-xl overflow-hidden border-2 transition-all ${activeMedia === img && !isVideoActive ? 'border-primary scale-105' : 'border-transparent opacity-60 hover:opacity-100'}`}
                >
                  <img src={img} className="w-full h-full object-cover" />
                </button>
              ))}
              {product.videoUrl && (
                <button
                  onClick={() => setIsVideoActive(true)}
                  className={`w-20 h-20 rounded-xl overflow-hidden border-2 flex items-center justify-center bg-secondary transition-all ${isVideoActive ? 'border-primary scale-105' : 'border-transparent opacity-60 hover:opacity-100'}`}
                >
                  <PlayCircle className="w-8 h-8 text-primary" />
                </button>
              )}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-8">
            <div>
              <span className="text-sm font-bold text-accent uppercase tracking-[0.2em]">{product.category}</span>
              <h1 className="text-4xl lg:text-5xl font-extrabold text-foreground mt-2 leading-tight">{product.name}</h1>
            </div>

            <div className="flex items-center gap-4">
               <div className="flex text-primary">
                 {[...Array(5)].map((_, i) => <Star key={i} className="w-5 h-5 fill-current" />)}
               </div>
               <span className="text-muted-foreground font-medium">(1,250 Verified Reviews)</span>
            </div>

            <div className="space-y-2">
              <div className="flex items-baseline gap-4">
                <span className="text-6xl font-black text-primary">{formatPrice(discountPrice || product.price, currency)}</span>
                {discountPrice && (
                  <>
                    <span className="text-2xl text-muted-foreground line-through decoration-destructive/50">{formatPrice(product.price, currency)}</span>
                    <span className="px-4 py-1 bg-destructive/10 text-destructive rounded-full text-sm font-bold tracking-tight">SAVE 20%</span>
                  </>
                )}
              </div>
            </div>

            <p className="text-xl text-muted-foreground leading-relaxed">{product.description}</p>

            {/* Inventory Status */}
            <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl border font-bold ${product.stock > 0 ? 'bg-green-500/5 border-green-500/20 text-green-500' : 'bg-red-500/5 border-red-500/20 text-red-500'}`}>
              {product.stock > 0 ? <Check className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
              {product.stock > 0 ? `INSTANT ACCESS AVAILABLE (${product.stock} left)` : 'SOLD OUT'}
            </div>

            {/* Quantity & Buy */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-center justify-between bg-secondary p-2 rounded-2xl border border-border">
                <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="w-12 h-12 flex items-center justify-center hover:bg-background rounded-xl transition-colors font-bold text-xl">−</button>
                <span className="text-xl font-black">{quantity}</span>
                <button onClick={() => setQuantity(Math.min(product.stock, quantity + 1))} className="w-12 h-12 flex items-center justify-center hover:bg-background rounded-xl transition-colors font-bold text-xl">+</button>
              </div>
              <button
                onClick={handleAddToCart}
                disabled={product.stock === 0 || addedToCart}
                className={`w-full py-4 rounded-2xl font-black text-xl flex items-center justify-center gap-3 transition-all transform active:scale-95 shadow-xl ${addedToCart ? 'bg-accent text-white' : 'bg-primary text-white hover:brightness-110'}`}
              >
                {addedToCart ? <Check className="w-6 h-6" /> : <ShoppingCart className="w-6 h-6" />}
                {addedToCart ? 'ADDED TO CART!' : 'GET ACCESS NOW'}
              </button>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-2 gap-4 pt-8 border-t border-border">
               <div className="flex items-center gap-3 text-muted-foreground">
                 <Shield className="w-6 h-6 text-primary" />
                 <span className="text-sm font-bold">Secure Checkout</span>
               </div>
               <div className="flex items-center gap-3 text-muted-foreground">
                 <Download className="w-6 h-6 text-primary" />
                 <span className="text-sm font-bold">Instant Download</span>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
