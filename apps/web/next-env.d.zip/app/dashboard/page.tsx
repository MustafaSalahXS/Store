'use client'

import { useAuth } from '@/lib/auth-context'
import { useStore } from '@/lib/store-context'
import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import Header from '@/components/header'
import { motion } from 'framer-motion'
import { LogOut, Store, ShoppingBag, TrendingUp, Users } from 'lucide-react'

export default function DashboardPage() {
  const { user, logout, isLoading } = useAuth()
  const { currentStore } = useStore()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading && !user) {
      router.push('/login')
    }
  }, [user, isLoading, router])

  const handleLogout = async () => {
    await logout()
    router.push('/')
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-secondary border-t-primary rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  if (!user) return null

  const stats = [
    {
      label: 'Orders',
      value: '24',
      icon: ShoppingBag,
      color: 'text-primary',
    },
    {
      label: 'Total Spent',
      value: '$1,234',
      icon: TrendingUp,
      color: 'text-accent',
    },
    {
      label: 'Saved Items',
      value: '8',
      icon: Store,
      color: 'text-primary',
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="section-container py-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-foreground mb-2">
                Welcome, {user.name}
              </h1>
              <p className="text-muted-foreground">
                Manage your account and orders
              </p>
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleLogout}
              className="flex items-center gap-2 px-6 py-3 bg-secondary text-foreground rounded-lg hover:opacity-80 transition-opacity"
            >
              <LogOut className="w-5 h-5" />
              Sign Out
            </motion.button>
          </div>
        </motion.div>

        {/* User Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-12 bg-card rounded-xl border border-border p-8"
        >
          <h2 className="text-2xl font-bold text-foreground mb-6">Account Information</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <p className="text-sm text-muted-foreground mb-2">Email</p>
              <p className="text-lg font-semibold text-foreground">{user.email}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-2">Account Type</p>
              <p className="text-lg font-semibold text-foreground capitalize">
                {user.role.replace('_', ' ')}
              </p>
            </div>
            {currentStore && (
              <div>
                <p className="text-sm text-muted-foreground mb-2">Store</p>
                <p className="text-lg font-semibold text-foreground">{currentStore.name}</p>
              </div>
            )}
          </div>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12"
        >
          {stats.map((stat, idx) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + idx * 0.1 }}
              className="bg-card rounded-xl border border-border p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-muted-foreground">
                  {stat.label}
                </h3>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <p className="text-3xl font-bold text-foreground">{stat.value}</p>
            </motion.div>
          ))}
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card rounded-xl border border-border p-8"
        >
          <h2 className="text-2xl font-bold text-foreground mb-6">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => router.push('/')}
              className="p-4 bg-secondary rounded-lg hover:opacity-80 transition-opacity text-center"
            >
              <ShoppingBag className="w-6 h-6 mx-auto mb-2 text-primary" />
              <p className="font-semibold text-foreground">Continue Shopping</p>
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="p-4 bg-secondary rounded-lg hover:opacity-80 transition-opacity text-center"
            >
              <TrendingUp className="w-6 h-6 mx-auto mb-2 text-accent" />
              <p className="font-semibold text-foreground">View Orders</p>
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="p-4 bg-secondary rounded-lg hover:opacity-80 transition-opacity text-center"
            >
              <Store className="w-6 h-6 mx-auto mb-2 text-primary" />
              <p className="font-semibold text-foreground">Saved Items</p>
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="p-4 bg-secondary rounded-lg hover:opacity-80 transition-opacity text-center"
            >
              <Users className="w-6 h-6 mx-auto mb-2 text-accent" />
              <p className="font-semibold text-foreground">Account Settings</p>
            </motion.button>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
