'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Header from '@/components/header'
import { useCart } from '@/lib/cart-context'
import { useAuth } from '@/lib/auth-context'
import { useStore } from '@/lib/store-context'
import { createOrder, PaymentMethod } from '@/lib/payments'
import { api } from '@/lib/api'
import { motion, AnimatePresence } from 'framer-motion'
import { ShoppingCart, CreditCard, MessageCircle, Wallet, AlertCircle, Check, ChevronRight, Loader, X } from 'lucide-react'
import { formatPrice } from '@/lib/currency'

const PAYMENT_METHODS: { id: PaymentMethod; name: string; icon: any; description: string }[] = [
  {
    id: 'card',
    name: 'Credit/Debit Card',
    icon: CreditCard,
    description: 'Visa, Mastercard via Paymob',
  },
  {
    id: 'vodafone_cash',
    name: 'Vodafone Cash',
    icon: Wallet,
    description: 'Mobile wallet payment',
  },
  {
    id: 'instapay',
    name: 'InstaPay',
    icon: Wallet,
    description: 'Bank transfer payment',
  },
  {
    id: 'whatsapp',
    name: 'WhatsApp Payment',
    icon: MessageCircle,
    description: 'Confirm payment via WhatsApp',
  },
]

export default function CheckoutPage() {
  const router = useRouter()
  const { user } = useAuth()
  const { currentStore } = useStore()
  const { items, total, clearCart } = useCart()

  const [step, setStep] = useState<'cart' | 'details' | 'payment'>('cart')
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>('card')
  const [isLoading, setIsLoading] = useState(false)
  const [orderCreated, setOrderCreated] = useState(false)
  const [orderId, setOrderId] = useState('')
  const [error, setError] = useState('')

  const [email, setEmail] = useState(user?.email || '')
  const [name, setName] = useState(user?.name || '')
  const [phone, setPhone] = useState('')

  // Paymob states
  const [paymobIframeUrl, setPaymobIframeUrl] = useState<string | null>(null)
  const [showPaymobModal, setShowPaymobModal] = useState(false)

  const currency = currentStore?.currency || 'USD'

  const tax = total * 0.14
  const shipping = total > 500 ? 0 : 50
  const grandTotal = total + tax + shipping

  if (items.length === 0 && !orderCreated) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="section-container py-24 text-center">
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
            <ShoppingCart className="w-24 h-24 mx-auto mb-6 text-muted-foreground opacity-20" />
            <h1 className="text-4xl font-black text-foreground mb-4 tracking-tight">Your cart is empty</h1>
            <button onClick={() => router.push('/')} className="px-10 py-4 bg-primary text-white rounded-2xl font-black text-lg shadow-xl hover:brightness-110">Start Shopping</button>
          </motion.div>
        </div>
      </div>
    )
  }

  const handleCreateOrder = async () => {
    if (!name || !email || !phone) {
      setError('Please fill in all contact details.')
      return
    }
    setIsLoading(true)
    setError('')

    try {
      const orderItems = items.map((item) => ({
        id: Math.random().toString(),
        product_id: item.productId,
        product_name: item.product.name,
        quantity: item.quantity,
        price: Number(item.product.discountPrice || item.product.discount_price || item.product.price),
        customizations: item.customizations,
      }))

      const result = await createOrder(
        currentStore?.id || '',
        { email, name, phone },
        orderItems,
        selectedMethod,
        user?.id
      )

      if (!result) throw new Error('Order creation failed.')

      setOrderId(result.id)
      setOrderCreated(true)
      
      // If Card payment, initiate Paymob
      if (selectedMethod === 'card') {
        try {
          const paymobData = await api.payments.paymob.create({
            orderId: result.id,
            amount: grandTotal,
            customer: { email, name, phone }
          })
          setPaymobIframeUrl(paymobData.iframeUrl)
          setShowPaymobModal(true)
        } catch (paymobErr) {
          console.error('Paymob error:', paymobErr)
          setError('Order created but failed to initiate payment. Please contact support.')
        }
      }

      clearCart()
      setStep('payment')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred.')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <div className="section-container py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          <div className="lg:col-span-2 space-y-12">
            {/* Steps Navigation */}
            <div className="flex items-center gap-4 bg-secondary/50 p-2 rounded-2xl border border-border w-fit">
              {(['cart', 'details', 'payment'] as const).map((s, i) => (
                <div key={s} className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${step === s ? 'bg-primary text-white' : 'bg-secondary text-muted-foreground'}`}>{i + 1}</div>
                  <span className={`text-sm font-bold capitalize ${step === s ? 'text-foreground' : 'text-muted-foreground'}`}>{s}</span>
                  {i < 2 && <ChevronRight className="w-4 h-4 text-muted-foreground opacity-30" />}
                </div>
              ))}
            </div>

            {error && <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center gap-3 text-red-500 font-bold"><AlertCircle className="w-5 h-5" /> {error}</div>}

            {step === 'cart' && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
                <h2 className="text-4xl font-black tracking-tight">Review Order</h2>
                <div className="space-y-4">
                  {items.map(item => (
                    <div key={item.productId} className="flex gap-6 p-6 bg-secondary/30 border border-border rounded-3xl">
                      <div className="w-24 h-24 bg-secondary rounded-2xl overflow-hidden"><img src={item.product.image} className="w-full h-full object-cover" /></div>
                      <div className="flex-1">
                        <h3 className="text-xl font-bold">{item.product.name}</h3>
                        <p className="text-muted-foreground font-medium">Qty: {item.quantity}</p>
                      </div>
                      <p className="text-xl font-black text-primary">{formatPrice(Number(item.product.discountPrice || item.product.price) * item.quantity, currency)}</p>
                    </div>
                  ))}
                </div>
                <button onClick={() => setStep('details')} className="w-full py-5 bg-primary text-white rounded-2xl font-black text-xl shadow-xl hover:brightness-110">Continue</button>
              </motion.div>
            )}

            {step === 'details' && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
                <h2 className="text-4xl font-black tracking-tight">Contact</h2>
                <div className="grid grid-cols-1 gap-6 bg-secondary/30 p-8 rounded-3xl border border-border">
                  <input value={name} onChange={e => setName(e.target.value)} className="w-full p-4 bg-background border border-border rounded-2xl font-bold" placeholder="Full Name" />
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full p-4 bg-background border border-border rounded-2xl font-bold" placeholder="Email Address" />
                  <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className="w-full p-4 bg-background border border-border rounded-2xl font-bold" placeholder="Phone Number" />
                </div>
                <div className="flex gap-4">
                  <button onClick={() => setStep('cart')} className="flex-1 py-5 bg-secondary rounded-2xl font-black text-xl">Back</button>
                  <button onClick={() => setStep('payment')} className="flex-1 py-5 bg-primary text-white rounded-2xl font-black text-xl shadow-xl">Payment</button>
                </div>
              </motion.div>
            )}

            {step === 'payment' && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
                 <h2 className="text-4xl font-black tracking-tight">{orderCreated ? 'Thank You!' : 'Payment'}</h2>
                 {!orderCreated ? (
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                     {PAYMENT_METHODS.map(method => (
                       <button key={method.id} onClick={() => setSelectedMethod(method.id)} className={`p-6 rounded-3xl border-2 text-left transition-all ${selectedMethod === method.id ? 'border-primary bg-primary/5' : 'border-border bg-secondary/30 hover:border-primary/50'}`}>
                         <method.icon className={`w-8 h-8 mb-4 ${selectedMethod === method.id ? 'text-primary' : 'text-muted-foreground'}`} />
                         <h3 className="text-xl font-bold">{method.name}</h3>
                         <p className="text-sm text-muted-foreground font-medium">{method.description}</p>
                       </button>
                     ))}
                   </div>
                 ) : (
                   <div className="p-12 bg-green-500/10 border border-green-500/20 rounded-[3rem] text-center">
                     <Check className="w-20 h-20 text-green-500 mx-auto mb-6" />
                     <h3 className="text-3xl font-black text-green-500">Order Placed!</h3>
                     <p className="text-muted-foreground font-bold mt-2">Order ID: #{orderId.slice(-6).toUpperCase()}</p>
                     {selectedMethod === 'card' && paymobIframeUrl && (
                        <button onClick={() => setShowPaymobModal(true)} className="mt-8 px-8 py-3 bg-primary text-white rounded-xl font-black shadow-lg">Open Payment Portal</button>
                     )}
                   </div>
                 )}
                 {!orderCreated ? (
                   <div className="flex gap-4">
                     <button onClick={() => setStep('details')} className="flex-1 py-5 bg-secondary rounded-2xl font-black text-xl">Back</button>
                     <button onClick={handleCreateOrder} disabled={isLoading} className="flex-1 py-5 bg-primary text-white rounded-2xl font-black text-xl shadow-xl flex items-center justify-center gap-3">
                       {isLoading && <Loader className="w-5 h-5 animate-spin" />} {selectedMethod === 'card' ? 'Pay Now' : 'Place Order'}
                     </button>
                   </div>
                 ) : (
                   <button onClick={() => router.push('/')} className="w-full py-5 bg-primary text-white rounded-2xl font-black text-xl shadow-xl">Return Home</button>
                 )}
              </motion.div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            <div className="bg-card p-8 rounded-[2.5rem] border border-border shadow-2xl sticky top-24">
              <h3 className="text-2xl font-black mb-8 border-b border-border pb-4 tracking-tight">Summary</h3>
              <div className="space-y-4">
                <div className="flex justify-between font-bold text-muted-foreground"><span>Subtotal</span><span>{formatPrice(total, currency)}</span></div>
                <div className="flex justify-between font-bold text-muted-foreground"><span>Tax (14%)</span><span>{formatPrice(tax, currency)}</span></div>
                <div className="flex justify-between font-bold text-muted-foreground"><span>Shipping</span><span>{shipping === 0 ? 'FREE' : formatPrice(shipping, currency)}</span></div>
                <div className="pt-6 mt-6 border-t-2 border-dashed border-border flex justify-between items-center"><span className="text-xl font-black">TOTAL</span><span className="text-3xl font-black text-primary">{formatPrice(grandTotal, currency)}</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Paymob Iframe Modal */}
      <AnimatePresence>
        {showPaymobModal && paymobIframeUrl && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-xl p-4 md:p-10">
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-white w-full max-w-5xl h-full max-h-[90vh] rounded-[2rem] overflow-hidden relative shadow-2xl">
              <button onClick={() => setShowPaymobModal(false)} className="absolute top-6 right-6 z-10 p-2 bg-black/10 hover:bg-black/20 rounded-full transition-colors"><X className="w-6 h-6 text-black"/></button>
              <iframe src={paymobIframeUrl} className="w-full h-full border-none" title="Paymob Payment" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
