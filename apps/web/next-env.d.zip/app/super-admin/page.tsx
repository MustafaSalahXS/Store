'use client'

import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import Header from '@/components/header'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Plus, Edit, Trash2, Eye, BarChart3, ShoppingCart, Users, Zap, 
  X, Loader, Settings, Shield, Store, LayoutGrid, Search, 
  Globe, Package, TrendingUp, Mail, UserPlus, Image as ImageIcon,
  AlertCircle, CheckCircle2, MoreVertical, LogOut, ExternalLink,
  Upload, Sun, Moon, Link as LinkIcon
} from 'lucide-react'
import { useAuth } from '@/lib/auth-context'
import { api } from '@/lib/api'
import { formatPrice } from '@/lib/currency'
import { supabase } from '@/lib/supabase'
import { useLanguage } from '@/lib/language-context'

export default function SuperAdminPage() {
  const { user, isLoading: isAuthLoading } = useAuth()
  const { t } = useLanguage()
  const router = useRouter()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])
  
  const [activeTab, setActiveTab] = useState<'stores' | 'users' | 'stats'>('stats')
  const [stores, setStores] = useState<any[]>([])
  const [users, setUsers] = useState<any[]>([])
  const [stats, setStats] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isUploading, setIsUploading] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState('')

  // Store Modal
  const [showStoreModal, setShowStoreModal] = useState(false)
  const [editingStore, setEditingStore] = useState<any>(null)
  const [storeFormData, setStoreFormData] = useState({
    name: '',
    description: '',
    logoUrl: '',
    darkLogoUrl: '',
    faviconUrl: '',
    bannerUrl: '',
    isActive: true,
    currency: 'USD',
    slug: '',
    ownerId: ''
  })

  // User Modal
  const [showEditUser, setShowEditUser] = useState(false)
  const [editingUser, setEditingUser] = useState<any>(null)
  const [userFormData, setUserFormData] = useState({
    role: '',
    storeId: ''
  })

  useEffect(() => {
    if (!isAuthLoading) {
      if (!user) router.push('/super-login')
      else if (user.role !== 'super_admin') router.push('/')
    }
  }, [user, isAuthLoading, router])

  const loadData = async () => {
    if (!user || user.role !== 'super_admin') return
    setIsLoading(true)
    try {
      const [storesData, usersData, statsData] = await Promise.all([
        api.admin.getAllStores(),
        api.admin.getUsers(),
        api.admin.getStats()
      ])
      setStores(storesData)
      setUsers(usersData)
      setStats(statsData)
    } catch (error) {
      console.error('Error loading super admin data:', error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => { loadData() }, [user])

  if (!mounted || isAuthLoading || isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background gap-4">
        <Loader className="w-10 h-10 animate-spin text-primary" />
        <p className="text-[10px] font-black text-muted-foreground uppercase tracking-[0.4em]">Initializing Control</p>
      </div>
    )
  }

  if (!user || user.role !== 'super_admin') return null

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: string) => {
    const file = e.target.files?.[0]
    if (!file) return

    setIsUploading(field)
    try {
      // Determine bucket based on field type
      let bucket = 'stores'
      if (field === 'logoUrl') bucket = 'LLogo'
      else if (field === 'darkLogoUrl') bucket = 'DLogo'
      else if (field === 'faviconUrl') bucket = 'FavIcon'
      else if (field === 'bannerUrl') bucket = 'Pics'
      else if (field === 'videoUrl') bucket = 'Vids'

      const fileName = `${Date.now()}-${file.name.replace(/\s+/g, '-')}`
      const { data, error } = await supabase.storage
        .from(bucket)
        .upload(fileName, file)

      if (error) throw error

      const { data: { publicUrl } } = supabase.storage
        .from(bucket)
        .getPublicUrl(fileName)

      setStoreFormData(prev => ({ ...prev, [field]: publicUrl }))
    } catch (error) {
      console.error('Upload failed:', error)
      const errorBucket = field === 'logoUrl' ? 'LLogo' : field === 'darkLogoUrl' ? 'DLogo' : field === 'faviconUrl' ? 'FavIcon' : 'Pics'
      alert(`Upload failed. Ensure bucket "${errorBucket}" exists in Supabase.`)
    } finally {
      setIsUploading(null)
    }
  }

  const openCreateStore = () => {
    setEditingStore(null)
    setStoreFormData({ 
      name: '', description: '', logoUrl: '', darkLogoUrl: '', faviconUrl: '', 
      bannerUrl: '', isActive: true, currency: 'USD', slug: '', ownerId: '' 
    })
    setShowStoreModal(true)
  }

  const openEditStore = (store: any) => {
    setEditingStore(store)
    setStoreFormData({
      name: store.name,
      description: store.description || '',
      logoUrl: store.logoUrl || '',
      darkLogoUrl: store.darkLogoUrl || '',
      faviconUrl: store.faviconUrl || '',
      bannerUrl: store.bannerUrl || '',
      isActive: store.isActive,
      currency: store.currency || 'USD',
      slug: store.slug || '',
      ownerId: store.ownerId || ''
    })
    setShowStoreModal(true)
  }

  const handleSaveStore = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    try {
      if (editingStore) {
        const updated = await api.admin.updateStore(editingStore.id, storeFormData)
        setStores(stores.map(s => s.id === editingStore.id ? { ...s, ...updated } : s))
        alert('SUCCESS: Store infrastructure updated.')
      } else {
        const created = await api.admin.createStore(storeFormData)
        setStores([created, ...stores])
        alert('SUCCESS: New store provisioned.')
      }
      setShowStoreModal(false)
    } catch (error) {
      alert('ERROR: Failed to save store configurations.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteStore = async (id: string) => {
    if (!confirm('CRITICAL: Delete this entire store? This action is permanent.')) return
    try {
      await api.admin.deleteStore(id)
      setStores(stores.filter(s => s.id !== id))
      setShowStoreModal(false)
      alert('SUCCESS: Store purged from infrastructure.')
    } catch (error) {
      alert('ERROR: Could not delete store. Ensure all dependent nodes are cleared.')
    }
  }

  const handleEditUser = (u: any) => {
    setEditingUser(u)
    setUserFormData({ role: u.role, storeId: u.storeId || '' })
    setShowEditUser(true)
  }

  const handleUpdateUser = async () => {
    setIsSubmitting(true)
    try {
      await api.admin.updateUserRole(editingUser.id, userFormData.role)
      await api.admin.assignStore(editingUser.id, userFormData.storeId || null)
      await loadData()
      setShowEditUser(false)
      alert('SUCCESS: User permissions reconfigured.')
    } catch (error) {
      alert('ERROR: Failed to update user clearance.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Delete this user account?')) return
    try {
      await api.admin.deleteUser(userId)
      setUsers(users.filter(u => u.id !== userId))
      alert('SUCCESS: User identity removed.')
    } catch (error) {
      alert('ERROR: Failed to delete user.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const filteredStores = stores.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (s.id && s.id.toLowerCase().includes(searchQuery.toLowerCase()))
  )

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div suppressHydrationWarning className="min-h-screen bg-background text-foreground pb-20">
      <Header />
      
      {/* Dynamic Header */}
      <div className="bg-primary/5 border-b border-border py-10 mb-10 overflow-hidden relative">
        <div className="section-container relative z-10">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="space-y-1">
              <div className="flex items-center gap-3">
                <div className="bg-primary p-2 rounded-xl text-white"><Shield className="w-5 h-5" /></div>
                <h1 className="text-3xl font-black tracking-tighter uppercase">{t('nav.admin')}</h1>
              </div>
              <p className="text-muted-foreground font-bold text-xs pl-10 uppercase tracking-widest opacity-60">System Management Console</p>
            </div>
            
            <div className="flex gap-2 bg-card/80 backdrop-blur-md p-1.5 rounded-2xl border border-border shadow-xl">
               {[
                 { id: 'stats', label: t('nav.analytics'), icon: BarChart3 },
                 { id: 'stores', label: t('nav.stores'), icon: Store },
                 { id: 'users', label: t('nav.customers'), icon: Users }
               ].map(tab => (
                 <button 
                   key={tab.id}
                   onClick={() => setActiveTab(tab.id as any)}
                   className={`flex items-center gap-2 px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all ${activeTab === tab.id ? 'bg-primary text-white shadow-lg' : 'text-muted-foreground hover:text-foreground'}`}
                 >
                   <tab.icon className="w-3.5 h-3.5" />
                   {tab.label}
                 </button>
               ))}
            </div>
          </div>
        </div>
      </div>

      <div className="section-container">
        {/* Actions Bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground opacity-50" />
            <input 
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search platform resources..."
              className="w-full pl-12 pr-6 py-4 bg-card border border-border rounded-2xl font-bold text-sm outline-none focus:border-primary transition-all"
            />
          </div>
          {activeTab === 'stores' && (
            <button onClick={openCreateStore} className="px-8 py-4 bg-primary text-white rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 shadow-lg hover:brightness-110 active:scale-95 transition-all">
              <Plus className="w-4 h-4" /> Provision New Store
            </button>
          )}
        </div>

        {/* Overview Stats */}
        {activeTab === 'stats' && stats && (
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { label: 'Active Stores', value: stats.storeCount, icon: Store, color: 'text-primary' },
                { label: 'Identified Users', value: stats.userCount, icon: Users, color: 'text-accent' },
                { label: 'Cloud Inventory', value: stats.productCount, icon: Package, color: 'text-primary' },
                { label: 'Transaction Load', value: stats.orderCount, icon: TrendingUp, color: 'text-accent' }
              ].map((s, i) => (
                <div key={i} className="bg-card rounded-[2rem] p-8 border border-border shadow-xl group relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4 opacity-5"><s.icon className="w-20 h-20" /></div>
                  <div className={`p-2 w-fit rounded-lg bg-secondary mb-4 ${s.color}`}><s.icon className="w-4 h-4" /></div>
                  <p className="text-[9px] font-black text-muted-foreground uppercase tracking-widest mb-1">{s.label}</p>
                  <p className="text-4xl font-black tracking-tighter">{s.value}</p>
                </div>
              ))}
           </div>
        )}

        {/* Stores Grid */}
        {activeTab === 'stores' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredStores.map(store => (
              <motion.div key={store.id} className="bg-card rounded-[2.5rem] border border-border shadow-xl overflow-hidden flex flex-col hover:border-primary/50 transition-all">
                <div className="h-24 bg-secondary/50 relative">
                  {store.bannerUrl && <img src={store.bannerUrl} className="w-full h-full object-cover" />}
                  <div className="absolute top-4 right-4"><span className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest ${store.isActive ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`}>{store.isActive ? 'Live' : 'Off'}</span></div>
                </div>
                <div className="p-8 flex-1 flex flex-col">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-14 h-14 bg-background rounded-2xl border border-border overflow-hidden -mt-14 relative z-10 shadow-xl">{store.logoUrl ? <img src={store.logoUrl} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Store className="w-5 h-5 opacity-20" /></div>}</div>
                    <h3 className="text-xl font-black tracking-tight leading-none">{store.name}</h3>
                  </div>
                  <p className="text-muted-foreground font-medium text-xs line-clamp-2 mb-6 flex-1 opacity-70">{store.description || 'Enterprise Node.'}</p>
                  <div className="flex gap-2">
                    <button onClick={() => openEditStore(store)} className="flex-1 py-3 bg-secondary rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-primary hover:text-white transition-all">Configure</button>
                    <a href={`/shop/${store.slug}`} target="_blank" className="p-3 bg-secondary rounded-xl hover:bg-accent hover:text-white transition-all"><ExternalLink className="w-4 h-4" /></a>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Users Table */}
        {activeTab === 'users' && (
          <div className="bg-card rounded-[2rem] border border-border shadow-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-secondary/30 text-[9px] uppercase tracking-[0.2em] text-muted-foreground border-b border-border">
                  <tr>
                    <th className="py-6 px-8 font-black">Identity</th>
                    <th className="py-6 px-8 font-black">Role</th>
                    <th className="py-6 px-8 font-black">Node</th>
                    <th className="py-6 px-8 font-black text-right">Op</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map(u => (
                    <tr key={u.id} className="border-b border-border/50 hover:bg-secondary/20 transition-all">
                      <td className="py-6 px-8"><div className="flex items-center gap-3"><div className="w-9 h-9 bg-primary/10 rounded-xl flex items-center justify-center font-black text-primary text-sm">{u.name.charAt(0)}</div><div><div className="font-black text-sm">{u.name}</div><div className="text-[10px] text-muted-foreground font-bold">{u.email}</div></div></div></td>
                      <td className="py-6 px-8"><span className={`px-3 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest ${u.role === 'super_admin' ? 'bg-primary text-white' : u.role === 'store_admin' ? 'bg-accent text-white' : 'bg-secondary text-muted-foreground'}`}>{u.role.replace('_',' ')}</span></td>
                      <td className="py-6 px-8"><div className="flex items-center gap-2 text-xs font-bold text-muted-foreground"><Store className="w-3 h-3 opacity-30" /> {u.store?.name || '---'}</div></td>
                      <td className="py-6 px-8 text-right"><div className="flex items-center justify-end gap-2"><button onClick={() => handleEditUser(u)} className="p-2 bg-secondary rounded-lg hover:bg-primary hover:text-white transition-all"><Edit className="w-4 h-4" /></button><button onClick={() => handleDeleteUser(u.id)} className="p-2 bg-secondary rounded-lg hover:bg-red-500 hover:text-white transition-all"><Trash2 className="w-4 h-4" /></button></div></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Store Management Modal */}
      <AnimatePresence>
        {showStoreModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md overflow-y-auto">
             <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="bg-card w-full max-w-lg rounded-[2.5rem] p-10 border border-border shadow-2xl relative my-auto">
                <button onClick={() => setShowStoreModal(false)} className="absolute top-8 right-8 p-2 hover:bg-secondary rounded-full"><X className="w-5 h-5"/></button>
                <div className="mb-6">
                   <h3 className="text-2xl font-black tracking-tighter uppercase">{editingStore ? 'Configure Node' : 'Initialize Node'}</h3>
                   <p className="text-[9px] font-black text-muted-foreground uppercase tracking-widest opacity-60">Store Infrastructure Protocol</p>
                </div>
                
                <form onSubmit={handleSaveStore} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-muted-foreground uppercase tracking-widest ml-1">Identity Name</label>
                      <input required value={storeFormData.name} onChange={e => setStoreFormData({...storeFormData, name: e.target.value})} className="w-full p-3 bg-secondary/50 border border-border rounded-xl font-bold text-xs outline-none focus:border-primary" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-muted-foreground uppercase tracking-widest ml-1">Unique Slug</label>
                      <input value={storeFormData.slug} onChange={e => setStoreFormData({...storeFormData, slug: e.target.value})} placeholder="auto-generated" className="w-full p-3 bg-secondary/50 border border-border rounded-xl font-bold text-xs" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-muted-foreground uppercase tracking-widest ml-1">System Currency</label>
                      <select required value={storeFormData.currency} onChange={e => setStoreFormData({...storeFormData, currency: e.target.value})} className="w-full p-3 bg-secondary/50 border border-border rounded-xl font-black text-xs outline-none">
                        <option value="EGP">EGP - Egyptian Pound</option>
                        <option value="USD">USD - US Dollar</option>
                        <option value="SAR">SAR - Saudi Riyal</option>
                        <option value="AED">AED - UAE Dirham</option>
                        <option value="EUR">EUR - Euro</option>
                        <option value="GBP">GBP - British Pound</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-muted-foreground uppercase tracking-widest ml-1">Assigned Admin</label>
                      <select required value={storeFormData.ownerId} onChange={e => setStoreFormData({...storeFormData, ownerId: e.target.value})} className="w-full p-3 bg-secondary/50 border border-border rounded-xl font-black text-xs outline-none">
                        <option value="">Select Admin</option>
                        {users.filter(u => u.role === 'store_admin' || u.role === 'super_admin').map(u => (
                          <option key={u.id} value={u.id}>{u.name} ({u.email})</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    {/* Logo Uploads */}
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-muted-foreground uppercase tracking-widest ml-1 flex items-center gap-2"><Sun className="w-2.5 h-2.5" /> Light Logo</label>
                      <div className="flex gap-2">
                        <input value={storeFormData.logoUrl} onChange={e => setStoreFormData({...storeFormData, logoUrl: e.target.value})} placeholder="URL" className="flex-1 p-3 bg-secondary/50 border border-border rounded-xl font-bold text-xs" />
                        <label className="p-3 bg-primary/10 text-primary rounded-xl cursor-pointer hover:bg-primary hover:text-white transition-all">
                          {isUploading === 'logoUrl' ? <Loader className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                          <input type="file" className="hidden" onChange={e => handleFileUpload(e, 'logoUrl')} accept="image/*" />
                        </label>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-muted-foreground uppercase tracking-widest ml-1 flex items-center gap-2"><Moon className="w-2.5 h-2.5" /> Dark Logo</label>
                      <div className="flex gap-2">
                        <input value={storeFormData.darkLogoUrl} onChange={e => setStoreFormData({...storeFormData, darkLogoUrl: e.target.value})} placeholder="URL" className="flex-1 p-3 bg-secondary/50 border border-border rounded-xl font-bold text-xs" />
                        <label className="p-3 bg-primary/10 text-primary rounded-xl cursor-pointer hover:bg-primary hover:text-white transition-all">
                          {isUploading === 'darkLogoUrl' ? <Loader className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                          <input type="file" className="hidden" onChange={e => handleFileUpload(e, 'darkLogoUrl')} accept="image/*" />
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-muted-foreground uppercase tracking-widest ml-1">FavIcon Resource</label>
                      <div className="flex gap-2">
                        <input value={storeFormData.faviconUrl} onChange={e => setStoreFormData({...storeFormData, faviconUrl: e.target.value})} placeholder="URL" className="flex-1 p-3 bg-secondary/50 border border-border rounded-xl font-bold text-xs" />
                        <label className="p-3 bg-primary/10 text-primary rounded-xl cursor-pointer hover:bg-primary hover:text-white transition-all">
                          {isUploading === 'faviconUrl' ? <Loader className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                          <input type="file" className="hidden" onChange={e => handleFileUpload(e, 'faviconUrl')} accept="image/*" />
                        </label>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-muted-foreground uppercase tracking-widest ml-1">Banner URL</label>
                      <div className="flex gap-2">
                        <input value={storeFormData.bannerUrl} onChange={e => setStoreFormData({...storeFormData, bannerUrl: e.target.value})} placeholder="URL" className="flex-1 p-3 bg-secondary/50 border border-border rounded-xl font-bold text-xs" />
                        <label className="p-3 bg-primary/10 text-primary rounded-xl cursor-pointer hover:bg-primary hover:text-white transition-all">
                          {isUploading === 'bannerUrl' ? <Loader className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                          <input type="file" className="hidden" onChange={e => handleFileUpload(e, 'bannerUrl')} accept="image/*" />
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[8px] font-black text-muted-foreground uppercase tracking-widest ml-1">Public Manifest (Description)</label>
                    <textarea value={storeFormData.description} onChange={e => setStoreFormData({...storeFormData, description: e.target.value})} className="w-full p-3 bg-secondary/50 border border-border rounded-xl font-medium text-[10px] min-h-[60px] outline-none" />
                  </div>
                  <div className="flex gap-3 mt-2">
                    <button type="submit" disabled={isSubmitting} className="flex-1 py-4 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg flex items-center justify-center gap-2">
                      {isSubmitting && <Loader className="w-4 h-4 animate-spin" />} {editingStore ? 'Update Structural Config' : 'Initialize Node'}
                    </button>
                    {editingStore && (
                      <button type="button" onClick={() => handleDeleteStore(editingStore.id)} className="p-4 bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white rounded-xl transition-all"><Trash2 className="w-4 h-4"/></button>
                    )}
                  </div>
                </form>
             </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* User Management Modal */}
      <AnimatePresence>
        {showEditUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
             <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="bg-card w-full max-w-sm rounded-[2rem] p-10 border border-border shadow-2xl relative">
                <button onClick={() => setShowEditUser(false)} className="absolute top-8 right-8 p-2 hover:bg-secondary rounded-full"><X className="w-5 h-5"/></button>
                <div className="mb-8 text-center">
                   <h3 className="text-xl font-black tracking-tighter uppercase">Permission Mapping</h3>
                   <div className="mt-4 p-4 bg-secondary/30 rounded-xl inline-block border border-border">
                      <p className="text-sm font-black">{editingUser.name}</p>
                      <p className="text-[9px] text-muted-foreground font-bold">{editingUser.email}</p>
                   </div>
                </div>
                <div className="space-y-5">
                  <div className="space-y-1.5">
                    <label className="text-[8px] font-black text-muted-foreground uppercase tracking-widest ml-1">Access Role</label>
                    <select value={userFormData.role} onChange={e => setUserFormData({...userFormData, role: e.target.value})} className="w-full p-4 bg-secondary/50 border border-border rounded-xl font-black text-xs outline-none">
                      <option value="customer">Regular Customer</option>
                      <option value="store_admin">Store Administrator</option>
                      <option value="super_admin">System SuperAdmin</option>
                    </select>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[8px] font-black text-muted-foreground uppercase tracking-widest ml-1">Linked Node</label>
                    <select value={userFormData.storeId} onChange={e => setUserFormData({...userFormData, storeId: e.target.value})} className="w-full p-4 bg-secondary/50 border border-border rounded-xl font-black text-xs outline-none">
                      <option value="">No Affiliation</option>
                      {stores.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                    </select>
                  </div>
                  <button onClick={handleUpdateUser} disabled={isSubmitting} className="w-full py-4 bg-primary text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl mt-2 flex items-center justify-center gap-3">
                    {isSubmitting && <Loader className="w-4 h-4 animate-spin" />} Sync Permission
                  </button>
                </div>
             </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  )
}
