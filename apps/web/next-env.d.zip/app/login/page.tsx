'use client'

import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import LoginForm from '@/components/auth/login-form'
import { motion } from 'framer-motion'
import { Check } from 'lucide-react'

import { Suspense } from 'react'

function LoginContent() {
  const searchParams = useSearchParams()
  const isRegistered = searchParams.get('registered') === 'true'

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="bg-card rounded-2xl border border-border p-8 shadow-lg">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Welcome Back</h1>
            <p className="text-muted-foreground">Sign in to your account</p>
          </div>

          {/* Success Message */}
          {isRegistered && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-6 flex items-center gap-3 p-4 bg-accent/10 border border-accent/30 rounded-lg"
            >
              <Check className="w-5 h-5 text-accent flex-shrink-0" />
              <p className="text-sm text-accent font-medium">Account created successfully!</p>
            </motion.div>
          )}

          {/* Login Form */}
          <LoginForm />

          {/* Footer */}
          <div className="mt-8 text-center">
            <p className="text-sm text-muted-foreground mb-2">
              Don&apos;t have an account?{' '}
              <Link href="/register" className="text-primary hover:underline font-semibold">
                Sign up
              </Link>
            </p>
          </div>

          {/* Demo Info */}
          <div className="mt-6 pt-6 border-t border-border text-center">
            <p className="text-xs text-muted-foreground mb-3">Demo Credentials</p>
            <div className="space-y-2 text-xs text-muted-foreground">
              <p>Email: <code className="bg-secondary px-2 py-1 rounded">demo@example.com</code></p>
              <p>Password: <code className="bg-secondary px-2 py-1 rounded">Demo@12345</code></p>
            </div>
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p>Or continue browsing as a guest</p>
          <Link href="/" className="text-primary hover:underline font-semibold">
            Back to Store
          </Link>
        </div>
      </motion.div>
    </div>
  )
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-background flex items-center justify-center p-4">Loading...</div>}>
      <LoginContent />
    </Suspense>
  )
}

