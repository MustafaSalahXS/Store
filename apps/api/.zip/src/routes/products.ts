import { Router } from 'express'
import { prisma } from 'database'

const router = Router()

// GET /api/products?storeId=xxx
router.get('/', async (req, res) => {
  try {
    const { storeId, category, limit = '20', offset = '0' } = req.query

    const where: any = { isActive: true }
    if (storeId) where.storeId = storeId as string
    if (category) where.category = category as string

    const products = await prisma.product.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: parseInt(limit as string),
      skip: parseInt(offset as string),
    })

    res.json(products)
  } catch (error) {
    console.error('Get products error:', error)
    res.status(500).json({ error: 'Failed to fetch products' })
  }
})

// GET /api/products/:id
router.get('/:id', async (req, res) => {
  try {
    const product = await prisma.product.findFirst({
      where: { id: req.params.id, isActive: true },
    })

    if (!product) return res.status(404).json({ error: 'Product not found' })
    res.json(product)
  } catch (error) {
    console.error('Get product error:', error)
    res.status(500).json({ error: 'Failed to fetch product' })
  }
})

// POST /api/products
router.post('/', async (req, res) => {
  try {
    const { storeId, name, description, price, category, stock, sku, cost, isActive, image, images, videoUrl } = req.body

    const product = await prisma.product.create({
      data: {
        storeId,
        name,
        description: description || '',
        price,
        category: category || '',
        stock: stock || 0,
        sku: sku || '',
        cost: cost || 0,
        isActive: isActive !== false,
        image: image || null,
        images: images || [],
        videoUrl: videoUrl || null,
      },
    })

    res.status(201).json(product)
  } catch (error) {
    console.error('Create product error:', error)
    res.status(500).json({ error: 'Failed to create product' })
  }
})

// PUT /api/products/:id
router.put('/:id', async (req, res) => {
  try {
    const product = await prisma.product.update({
      where: { id: req.params.id },
      data: req.body,
    })

    res.json(product)
  } catch (error) {
    console.error('Update product error:', error)
    res.status(500).json({ error: 'Failed to update product' })
  }
})

// DELETE /api/products/:id
router.delete('/:id', async (req, res) => {
  try {
    await prisma.product.delete({ where: { id: req.params.id } })
    res.json({ success: true })
  } catch (error) {
    console.error('Delete product error:', error)
    res.status(500).json({ error: 'Failed to delete product' })
  }
})

export { router as productsRouter }
