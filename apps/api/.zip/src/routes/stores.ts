import { Router } from 'express'
import { prisma } from 'database'

const router = Router()

// GET /api/stores
router.get('/', async (req, res) => {
  try {
    const { ownerId } = req.query

    const where: any = { isActive: true }
    if (ownerId) where.ownerId = ownerId as string

    const stores = await prisma.store.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    })

    res.json(stores)
  } catch (error) {
    console.error('Get stores error:', error)
    res.status(500).json({ error: 'Failed to fetch stores' })
  }
})

// GET /api/stores/:id
router.get('/:id', async (req, res) => {
  try {
    const store = await prisma.store.findUnique({
      where: { id: req.params.id },
      include: { _count: { select: { products: true, orders: true } } },
    })

    if (!store) return res.status(404).json({ error: 'Store not found' })
    res.json(store)
  } catch (error) {
    console.error('Get store error:', error)
    res.status(500).json({ error: 'Failed to fetch store' })
  }
})

// GET /api/stores/slug/:slug
router.get('/slug/:slug', async (req, res) => {
  try {
    const store = await prisma.store.findUnique({
      where: { slug: req.params.slug },
    })

    if (!store) return res.status(404).json({ error: 'Store not found' })
    res.json(store)
  } catch (error) {
    console.error('Get store by slug error:', error)
    res.status(500).json({ error: 'Failed to fetch store' })
  }
})

// POST /api/stores
router.post('/', async (req, res) => {
  try {
    const { name, description, ownerId, slug } = req.body

    const store = await prisma.store.create({
      data: {
        name,
        slug: slug || `${name.toLowerCase().replace(/\s+/g, '-')}-${Date.now()}`,
        description: description || '',
        ownerId,
        isActive: true,
      },
    })

    res.status(201).json(store)
  } catch (error) {
    console.error('Create store error:', error)
    res.status(500).json({ error: 'Failed to create store' })
  }
})

// PUT /api/stores/:id
router.put('/:id', async (req, res) => {
  try {
    const store = await prisma.store.update({
      where: { id: req.params.id },
      data: req.body,
    })

    res.json(store)
  } catch (error) {
    console.error('Update store error:', error)
    res.status(500).json({ error: 'Failed to update store' })
  }
})

export { router as storesRouter }
