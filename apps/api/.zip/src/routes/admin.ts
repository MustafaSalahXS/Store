import { Router } from 'express'
import { prisma } from 'database'
import { createClient } from '@supabase/supabase-js'

const router = Router()

// GET /api/admin/users  (super admin: list all users)
router.get('/users', async (req, res) => {
  try {
    const users = await prisma.user.findMany({
      include: { store: { select: { id: true, name: true } } },
      orderBy: { createdAt: 'desc' },
    })

    res.json(users)
  } catch (error) {
    console.error('Get users error:', error)
    res.status(500).json({ error: 'Failed to fetch users' })
  }
})

// PATCH /api/admin/users/:id/role
router.patch('/users/:id/role', async (req, res) => {
  try {
    const { role } = req.body
    const user = await prisma.user.update({
      where: { id: req.params.id },
      data: { role },
    })

    res.json(user)
  } catch (error) {
    console.error('Update user role error:', error)
    res.status(500).json({ error: 'Failed to update role' })
  }
})

// DELETE /api/admin/users/:id (super admin: delete user)
router.delete('/users/:id', async (req, res) => {
  try {
    const userId = req.params.id
    // 1. Delete from Supabase
    await prisma.$executeRaw`SELECT 1` // Placeholder for actual supabase admin check if needed
    // In a real app, you'd use supabaseAdmin.auth.admin.deleteUser(userId)
    
    // 2. Delete from our DB
    await prisma.user.delete({ where: { id: userId } })
    
    res.json({ success: true })
  } catch (error) {
    console.error('Delete user error:', error)
    res.status(500).json({ error: 'Failed to delete user' })
  }
})

// PATCH /api/admin/users/:id/assign-store (super admin: assign user to store)
router.patch('/users/:id/assign-store', async (req, res) => {
  try {
    const { storeId } = req.body
    const user = await prisma.user.update({
      where: { id: req.params.id },
      data: { storeId: storeId || null },
    })
    res.json(user)
  } catch (error) {
    console.error('Assign store error:', error)
    res.status(500).json({ error: 'Failed to assign store' })
  }
})

// GET /api/admin/stores  (super admin: list ALL stores)
router.get('/stores', async (req, res) => {
  try {
    const stores = await prisma.store.findMany({
      include: {
        _count: { select: { products: true, orders: true, users: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    res.json(stores)
  } catch (error) {
    console.error('Get all stores error:', error)
    res.status(500).json({ error: 'Failed to fetch stores' })
  }
})

// PUT /api/admin/stores/:id (super admin: update ANY store)
router.put('/stores/:id', async (req, res) => {
  try {
    const store = await prisma.store.update({
      where: { id: req.params.id },
      data: req.body,
    })
    res.json(store)
  } catch (error) {
    console.error('Update store error:', error)
    res.status(500).json({ error: 'Failed to update store' })
  }
})

// POST /api/admin/stores (super admin: create new store)
router.post('/stores', async (req, res) => {
  try {
    const { name, slug, currency, description, logoUrl, darkLogoUrl, faviconUrl, ownerId } = req.body
    
    // We need an ownerId. If not provided, we try to use the current admin's ID
    let finalOwnerId = ownerId

    if (!finalOwnerId) {
      // Extract from token if possible
      const token = req.headers.authorization?.replace('Bearer ', '')
      if (token) {
        const supabaseClient = createClient(
          process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.SUPABASE_URL || '',
          process.env.SUPABASE_ANON_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
        )
        const { data: { user } } = await supabaseClient.auth.getUser(token)
        if (user) finalOwnerId = user.id
      }
    }

    if (!finalOwnerId) {
      // Fallback: Use the first superadmin in the system if all else fails
      const firstAdmin = await prisma.user.findFirst({ where: { role: 'super_admin' } })
      finalOwnerId = firstAdmin?.id
    }

    if (!finalOwnerId) {
      return res.status(400).json({ error: 'Owner ID is required' })
    }

    const store = await prisma.store.create({
      data: {
        name,
        slug: slug || `${name.toLowerCase().replace(/\s+/g, '-')}-${Date.now()}`,
        currency: currency || 'USD',
        description,
        logoUrl,
        darkLogoUrl,
        faviconUrl,
        isActive: true,
        ownerId: finalOwnerId,
      },
    })
    res.status(201).json(store)
  } catch (error) {
    console.error('Create store error:', error)
    res.status(500).json({ error: 'Failed to create store' })
  }
})

// DELETE /api/admin/stores/:id (super admin: delete store)
router.delete('/stores/:id', async (req, res) => {
  try {
    const storeId = req.params.id
    
    console.log(`Starting ROBUST deep purge for store ${storeId}...`)
    
    // 1. Get all dependent IDs
    const orders = await prisma.order.findMany({ where: { storeId }, select: { id: true } })
    const orderIds = orders.map(o => o.id)
    
    const products = await prisma.product.findMany({ where: { storeId }, select: { id: true } })
    const productIds = products.map(p => p.id)

    // 2. Perform sequential deletion to avoid constraint races
    await prisma.$transaction([
      // Delete Order Items
      prisma.orderItem.deleteMany({ where: { orderId: { in: orderIds } } }),
      // Delete Payments
      prisma.payment.deleteMany({ where: { orderId: { in: orderIds } } }),
      // Delete Deliveries
      prisma.delivery.deleteMany({ where: { storeId } }),
      // Delete Orders
      prisma.order.deleteMany({ where: { storeId } }),
      // Delete Products
      prisma.product.deleteMany({ where: { storeId } }),
      // Unlink Users
      prisma.user.updateMany({ 
        where: { storeId }, 
        data: { storeId: null } 
      }),
      // Finally delete the store
      prisma.store.delete({ where: { id: storeId } })
    ])

    console.log(`ROBUST Deep purge complete for store ${storeId}`)
    res.json({ success: true })
  } catch (error) {
    console.error('Delete store error:', error)
    res.status(500).json({ error: 'Failed to delete store. System constraints persistent.' })
  }
})

// GET /api/admin/stats  (super admin: platform stats)
router.get('/stats', async (req, res) => {
  try {
    const [storeCount, userCount, productCount, orderCount] = await Promise.all([
      prisma.store.count(),
      prisma.user.count(),
      prisma.product.count(),
      prisma.order.count(),
    ])

    res.json({ storeCount, userCount, productCount, orderCount })
  } catch (error) {
    console.error('Get stats error:', error)
    res.status(500).json({ error: 'Failed to fetch stats' })
  }
})

export { router as adminRouter }
